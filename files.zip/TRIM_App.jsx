import { useState, useEffect } from "react";

const COLORS = {
  brand: "#1A1A1A",
  accent: "#E8A23C",
  accentDark: "#C4841A",
  accentLight: "#FDF3E0",
  green: "#15803D",
  greenBg: "#DCFCE7",
  red: "#DC2626",
  redBg: "#FEE2E2",
  muted: "#6B7280",
  border: "#E5E7EB",
  surface: "#F9F8F6",
  white: "#FFFFFF",
  dark: "#111827",
};

// Section 5.6 — Transport Fee Formula
// Transport Fee = max(₦500, min(distance_km × base_rate × traffic_multiplier, ₦4,500))
const BASE_RATE = 120; // ₦120/km
const MIN_FEE = 500;
const MAX_FEE = 4500;
const MAX_FEE_OUT_OF_ZONE = 6500;
const TRAFFIC_MULTIPLIERS = {
  light:    { value: 1.0, label: "Light",    badge: "+0%",   color: "#15803D", bg: "#DCFCE7" },
  moderate: { value: 1.2, label: "Moderate", badge: "+20%",  color: "#B45309", bg: "#FEF3C7" },
  heavy:    { value: 1.4, label: "Heavy",    badge: "+40%",  color: "#C2410C", bg: "#FFEDD5" },
  gridlock: { value: 1.6, label: "Gridlock", badge: "+60%",  color: "#DC2626", bg: "#FEE2E2" },
};

function calcTransportFee(distanceKm, trafficKey, outOfZone = false) {
  const cap = outOfZone ? MAX_FEE_OUT_OF_ZONE : MAX_FEE;
  const multiplier = TRAFFIC_MULTIPLIERS[trafficKey].value;
  const raw = distanceKm * BASE_RATE * multiplier;
  return Math.round(Math.max(MIN_FEE, Math.min(raw, cap)));
}

// Worked examples from concept note §5.6.2
const SAMPLE_ROUTES = [
  { label: "Ikeja → Ikeja (same area)", distance: 2.8,  traffic: "light",    zone: "Ikeja" },
  { label: "Yaba → Lekki Phase 1",      distance: 18,   traffic: "moderate", zone: "Yaba" },
  { label: "Ikeja → Victoria Island",   distance: 24,   traffic: "heavy",    zone: "Ikeja" },
  { label: "Surulere → Ajah",           distance: 38,   traffic: "gridlock", zone: "Surulere" },
];

const BARBERS = [
  {
    id: 1,
    name: "Biodun Cuts",
    handle: "biodun-cuts",
    location: "Ikeja, Lagos",
    specialty: "Fades & Tapers",
    rating: 4.9,
    reviews: 312,
    price: "₦2,500",
    badge: "Top Rated",
    wait: "~15 min",
    slots: ["9:00", "10:30", "14:00", "16:00"],
    tags: ["Precise Lines", "Great Fade", "Punctual"],
    mobile: false,
    avatar: "BC",
    color: "#E8A23C",
    services: [
      { name: "Classic Haircut", price: 2500, duration: "45 min" },
      { name: "Fade + Beard Trim", price: 3500, duration: "60 min" },
      { name: "Shape-Up Only", price: 1500, duration: "20 min" },
      { name: "Full Styling", price: 4500, duration: "75 min" },
    ],
  },
  {
    id: 2,
    name: "Chisom Mobile Pro",
    handle: "chisom-mobile",
    location: "Lekki / Ajah (Mobile)",
    specialty: "Mobile Barber",
    rating: 4.8,
    reviews: 189,
    price: "₦4,000",
    badge: "Mobile Pro",
    wait: "~30 min ETA",
    slots: ["8:00", "11:00", "15:00", "18:00"],
    tags: ["Friendly", "Right on Time", "Clean Kit"],
    mobile: true,
    avatar: "CM",
    color: "#3B82F6",
    services: [
      { name: "Home Haircut", price: 4000, duration: "60 min" },
      { name: "Home Fade + Beard", price: 5500, duration: "75 min" },
      { name: "Event Grooming", price: 8000, duration: "90 min" },
    ],
  },
  {
    id: 3,
    name: "Queens Salon Ikeja",
    handle: "queens-salon-ikeja",
    location: "Ikeja GRA, Lagos",
    specialty: "Braids & Natural Hair",
    rating: 4.7,
    reviews: 241,
    price: "₦6,000",
    badge: "Academy Certified",
    wait: "Walk-ins welcome",
    slots: ["10:00", "12:00", "14:30", "17:00"],
    tags: ["Professional", "Clean Space", "Good Value"],
    mobile: false,
    avatar: "QS",
    color: "#EC4899",
    services: [
      { name: "Knotless Braids", price: 12000, duration: "180 min" },
      { name: "Box Braids", price: 9000, duration: "150 min" },
      { name: "Natural Wash & Style", price: 6000, duration: "90 min" },
      { name: "Scalp Treatment", price: 4500, duration: "60 min" },
    ],
  },
  {
    id: 4,
    name: "Emeka Razors",
    handle: "emeka-razors",
    location: "Victoria Island, Lagos",
    specialty: "Luxury Grooming",
    rating: 5.0,
    reviews: 98,
    price: "₦5,000",
    badge: "Premium",
    wait: "Appointment only",
    slots: ["9:30", "11:30", "14:00", "16:30"],
    tags: ["Exceptional", "Hot Towel Shave", "Great Value"],
    mobile: false,
    avatar: "ER",
    color: "#7C3AED",
    services: [
      { name: "Luxury Haircut", price: 5000, duration: "60 min" },
      { name: "Hot Towel Shave", price: 4000, duration: "45 min" },
      { name: "Full Grooming Package", price: 10000, duration: "120 min" },
    ],
  },
];

const PRODUCTS = [
  { id: 1, name: "Wahl Magic Clip", category: "Clippers", price: 48000, rating: 4.8, seller: "ProKits NG" },
  { id: 2, name: "Beard Conditioning Oil", category: "Beard Care", price: 3500, rating: 4.6, seller: "GreenRoot" },
  { id: 3, name: "Fade Brush Set", category: "Tools", price: 2200, rating: 4.5, seller: "BarberSupply" },
  { id: 4, name: "Starter Barber Kit", category: "Kits", price: 85000, rating: 4.9, seller: "ProKits NG" },
];

function StarRating({ rating, size = 14 }) {
  return (
    <span style={{ display: "inline-flex", gap: 1, alignItems: "center" }}>
      {[1, 2, 3, 4, 5].map((s) => (
        <svg key={s} width={size} height={size} viewBox="0 0 16 16" fill={s <= Math.round(rating) ? COLORS.accent : "#D1D5DB"}>
          <path d="M8 1l1.8 3.6L14 5.3l-3 2.9.7 4.1L8 10.3l-3.7 1.9.7-4.1-3-2.9 4.2-.7z" />
        </svg>
      ))}
      <span style={{ fontSize: size - 1, color: COLORS.muted, marginLeft: 3 }}>{rating}</span>
    </span>
  );
}

function Badge({ children, color = COLORS.accent, bg = COLORS.accentLight }) {
  return (
    <span style={{
      display: "inline-block",
      fontSize: 11,
      fontWeight: 600,
      padding: "2px 8px",
      borderRadius: 20,
      background: bg,
      color,
      letterSpacing: "0.02em",
    }}>
      {children}
    </span>
  );
}

function Avatar({ initials, color, size = 48 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: color + "22",
      border: `2px solid ${color}55`,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.3, fontWeight: 700, color,
      flexShrink: 0,
    }}>
      {initials}
    </div>
  );
}

function BarberCard({ barber, onClick }) {
  return (
    <div
      onClick={() => onClick(barber)}
      style={{
        background: COLORS.white,
        border: `1px solid ${COLORS.border}`,
        borderRadius: 16,
        padding: "16px",
        cursor: "pointer",
        transition: "all 0.15s",
        boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
      }}
      onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 16px rgba(0,0,0,0.1)"}
      onMouseLeave={e => e.currentTarget.style.boxShadow = "0 1px 3px rgba(0,0,0,0.06)"}
    >
      <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
        <Avatar initials={barber.avatar} color={barber.color} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15, color: COLORS.dark }}>{barber.name}</div>
              <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 1 }}>{barber.location}</div>
            </div>
            <Badge>{barber.badge}</Badge>
          </div>
          <div style={{ marginTop: 6 }}>
            <StarRating rating={barber.rating} />
            <span style={{ fontSize: 12, color: COLORS.muted, marginLeft: 4 }}>({barber.reviews} reviews)</span>
          </div>
        </div>
      </div>
      <div style={{ marginTop: 12, display: "flex", gap: 6, flexWrap: "wrap" }}>
        {barber.tags.map(t => (
          <span key={t} style={{ fontSize: 11, padding: "3px 8px", borderRadius: 12, background: COLORS.surface, color: COLORS.muted, border: `1px solid ${COLORS.border}` }}>
            {t}
          </span>
        ))}
      </div>
      <div style={{ marginTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <span style={{ fontWeight: 700, fontSize: 16, color: COLORS.dark }}>{barber.price}</span>
          <span style={{ fontSize: 12, color: COLORS.muted }}> /service</span>
        </div>
        <div style={{ fontSize: 12, color: barber.mobile ? "#3B82F6" : COLORS.green, fontWeight: 500 }}>
          {barber.mobile ? "🏠 Mobile · +transport fee" : `⏱ Wait ${barber.wait}`}
        </div>
      </div>
      {barber.mobile && (
        <div style={{ marginTop: 8, fontSize: 11, color: "#60A5FA", background: "#EFF6FF", borderRadius: 8, padding: "5px 10px" }}>
          Transport: ₦{BASE_RATE}/km × traffic · Zone 15km · Always charged digitally
        </div>
      )}
    </div>
  );
}

function BottomNav({ screen, setScreen }) {
  const items = [
    { id: "home", icon: "🏠", label: "Home" },
    { id: "discover", icon: "🔍", label: "Discover" },
    { id: "bookings", icon: "📅", label: "Bookings" },
    { id: "marketplace", icon: "🛍", label: "Shop" },
    { id: "profile", icon: "👤", label: "Profile" },
  ];
  return (
    <div style={{
      position: "sticky", bottom: 0, left: 0, right: 0,
      background: COLORS.white,
      borderTop: `1px solid ${COLORS.border}`,
      display: "flex", justifyContent: "space-around",
      padding: "8px 0 12px",
      zIndex: 100,
    }}>
      {items.map(item => (
        <button key={item.id} onClick={() => setScreen(item.id)} style={{
          background: "none", border: "none", cursor: "pointer",
          display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
          padding: "4px 8px",
          opacity: screen === item.id ? 1 : 0.45,
          transition: "opacity 0.15s",
        }}>
          <span style={{ fontSize: 20 }}>{item.icon}</span>
          <span style={{ fontSize: 10, fontWeight: screen === item.id ? 700 : 400, color: screen === item.id ? COLORS.accent : COLORS.muted }}>
            {item.label}
          </span>
        </button>
      ))}
    </div>
  );
}

function HomeScreen({ setScreen, setSelectedBarber }) {
  const upcomingAppt = {
    barber: "Biodun Cuts",
    service: "Fade + Beard Trim",
    time: "Saturday, May 24 · 9:00 AM",
    status: "Confirmed",
  };

  return (
    <div style={{ padding: "0 16px", paddingBottom: 8 }}>
      <div style={{ padding: "24px 0 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 13, color: COLORS.muted }}>Good morning</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark, letterSpacing: "-0.5px" }}>Emeka 👋</div>
        </div>
        <div style={{ position: "relative" }}>
          <div style={{ width: 40, height: 40, borderRadius: "50%", background: COLORS.accentLight, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>
            🔔
          </div>
          <div style={{ position: "absolute", top: 0, right: 0, width: 10, height: 10, background: COLORS.red, borderRadius: "50%", border: "2px solid white" }} />
        </div>
      </div>

      <div style={{
        background: `linear-gradient(135deg, ${COLORS.dark} 0%, #2D1B69 100%)`,
        borderRadius: 20,
        padding: "20px",
        color: "white",
        marginBottom: 20,
        position: "relative",
        overflow: "hidden",
      }}>
        <div style={{ position: "absolute", right: -20, top: -20, fontSize: 100, opacity: 0.06 }}>✂</div>
        <div style={{ fontSize: 11, opacity: 0.7, marginBottom: 4, letterSpacing: "0.05em", textTransform: "uppercase" }}>Next Appointment</div>
        <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 2 }}>{upcomingAppt.barber}</div>
        <div style={{ fontSize: 13, opacity: 0.85 }}>{upcomingAppt.service}</div>
        <div style={{ fontSize: 12, opacity: 0.7, marginTop: 4 }}>{upcomingAppt.time}</div>
        <div style={{ marginTop: 14, display: "flex", gap: 8 }}>
          <button style={{ background: COLORS.accent, color: "white", border: "none", borderRadius: 10, padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
            View Details
          </button>
          <button style={{ background: "rgba(255,255,255,0.15)", color: "white", border: "1px solid rgba(255,255,255,0.25)", borderRadius: 10, padding: "8px 16px", fontSize: 13, cursor: "pointer" }}>
            Reschedule
          </button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
        {[
          { icon: "📍", label: "Book Nearby", sub: "Find barbers", action: "discover", color: "#EFF6FF" },
          { icon: "🏠", label: "Mobile Barber", sub: "Come to me", action: "mobile", color: "#F0FDF4" },
          { icon: "🚗", label: "Transport Fees", sub: "Calculate live", action: "transportCalc", color: "#FFF7ED" },
          { icon: "🛍", label: "Shop Products", sub: "Grooming kits", action: "marketplace", color: "#FDF4FF" },
        ].map(item => (
          <div key={item.label} onClick={() => setScreen(item.action)}
            style={{
              background: item.color, borderRadius: 14, padding: "14px", cursor: "pointer",
              border: `1px solid ${COLORS.border}`,
            }}>
            <div style={{ fontSize: 24, marginBottom: 6 }}>{item.icon}</div>
            <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark }}>{item.label}</div>
            <div style={{ fontSize: 12, color: COLORS.muted }}>{item.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ marginBottom: 8 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.dark }}>Nearby Barbers</div>
          <button onClick={() => setScreen("discover")} style={{ background: "none", border: "none", color: COLORS.accent, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
            See All →
          </button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {BARBERS.slice(0, 2).map(b => (
            <BarberCard key={b.id} barber={b} onClick={(barber) => {
              setSelectedBarber(barber);
              setScreen("barberProfile");
            }} />
          ))}
        </div>
      </div>

      <div style={{ marginTop: 20 }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.dark, marginBottom: 12 }}>Your TRIM Wallet</div>
        <div style={{
          background: COLORS.white, border: `1px solid ${COLORS.border}`,
          borderRadius: 16, padding: 16,
          display: "flex", justifyContent: "space-between", alignItems: "center",
        }}>
          <div>
            <div style={{ fontSize: 12, color: COLORS.muted }}>Available Balance</div>
            <div style={{ fontSize: 24, fontWeight: 800, color: COLORS.dark }}>₦12,500</div>
            <div style={{ fontSize: 12, color: COLORS.green, marginTop: 2 }}>🏆 340 TRIM Points</div>
          </div>
          <button style={{ background: COLORS.accent, color: "white", border: "none", borderRadius: 12, padding: "10px 18px", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
            Top Up
          </button>
        </div>
      </div>
    </div>
  );
}

function DiscoverScreen({ setScreen, setSelectedBarber }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const filters = ["All", "Barbers", "Salons", "Mobile", "4.8+ Stars"];

  const filtered = BARBERS.filter(b => {
    if (search && !b.name.toLowerCase().includes(search.toLowerCase()) && !b.specialty.toLowerCase().includes(search.toLowerCase())) return false;
    if (filter === "Mobile" && !b.mobile) return false;
    if (filter === "4.8+ Stars" && b.rating < 4.8) return false;
    if (filter === "Barbers" && b.mobile) return false;
    return true;
  });

  return (
    <div style={{ padding: "0 16px", paddingBottom: 8 }}>
      <div style={{ paddingTop: 24, paddingBottom: 16 }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark, letterSpacing: "-0.5px" }}>Discover</div>
        <div style={{ fontSize: 13, color: COLORS.muted, marginTop: 2 }}>Find your perfect barber in Lagos</div>
      </div>

      <div style={{ position: "relative", marginBottom: 14 }}>
        <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>🔍</span>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search barbers, salons, specialties…"
          style={{
            width: "100%", padding: "12px 12px 12px 38px",
            borderRadius: 12, border: `1px solid ${COLORS.border}`,
            fontSize: 14, outline: "none", background: COLORS.white,
            boxSizing: "border-box",
          }}
        />
      </div>

      <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 8, marginBottom: 16, scrollbarWidth: "none" }}>
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            flexShrink: 0, padding: "7px 14px", borderRadius: 20,
            border: `1px solid ${filter === f ? COLORS.accent : COLORS.border}`,
            background: filter === f ? COLORS.accent : COLORS.white,
            color: filter === f ? "white" : COLORS.muted,
            fontSize: 13, fontWeight: 500, cursor: "pointer",
          }}>
            {f}
          </button>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "40px 0", color: COLORS.muted }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>🔍</div>
            <div>No results found</div>
          </div>
        ) : filtered.map(b => (
          <BarberCard key={b.id} barber={b} onClick={(barber) => {
            setSelectedBarber(barber);
            setScreen("barberProfile");
          }} />
        ))}
      </div>
    </div>
  );
}

function BarberProfileScreen({ barber, setScreen, setBookingBarber }) {
  if (!barber) return null;
  const [activeTab, setActiveTab] = useState("services");

  return (
    <div style={{ paddingBottom: 8 }}>
      <div style={{ padding: "16px 16px 0" }}>
        <button onClick={() => setScreen("discover")} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: COLORS.dark, padding: 0, marginBottom: 8 }}>
          ← 
        </button>
      </div>

      <div style={{ padding: "0 16px 20px", borderBottom: `1px solid ${COLORS.border}` }}>
        <div style={{ display: "flex", gap: 16, alignItems: "center", marginBottom: 16 }}>
          <Avatar initials={barber.avatar} color={barber.color} size={72} />
          <div>
            <div style={{ fontSize: 20, fontWeight: 800, color: COLORS.dark }}>{barber.name}</div>
            <div style={{ fontSize: 13, color: COLORS.muted, marginTop: 2 }}>📍 {barber.location}</div>
            <div style={{ marginTop: 6, display: "flex", gap: 6, alignItems: "center" }}>
              <StarRating rating={barber.rating} size={13} />
              <span style={{ fontSize: 12, color: COLORS.muted }}>({barber.reviews} reviews)</span>
              <Badge>{barber.badge}</Badge>
            </div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
          {barber.tags.map(t => (
            <span key={t} style={{ fontSize: 12, padding: "4px 10px", borderRadius: 12, background: COLORS.surface, color: COLORS.muted, border: `1px solid ${COLORS.border}` }}>
              ✓ {t}
            </span>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, textAlign: "center" }}>
          {[
            { label: "Reviews", value: barber.reviews },
            { label: "Rating", value: barber.rating + "★" },
            barber.mobile
              ? { label: "Service Zone", value: "15km" }
              : { label: "Price from", value: barber.price },
          ].map(s => (
            <div key={s.label} style={{ background: COLORS.surface, borderRadius: 10, padding: "10px 6px" }}>
              <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.dark }}>{s.value}</div>
              <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
        {barber.mobile && (
          <div style={{ marginTop: 12, background: "#EFF6FF", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#1D4ED8" }}>
            <span style={{ fontWeight: 600 }}>🏠 Mobile Barber</span> · Transport fee calculated live at booking (₦{BASE_RATE}/km × traffic multiplier) · Max zone 15km · §5.6
          </div>
        )}
      </div>

      <div style={{ display: "flex", borderBottom: `1px solid ${COLORS.border}` }}>
        {["services", "portfolio", "reviews"].map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} style={{
            flex: 1, padding: "12px", background: "none", border: "none",
            borderBottom: `2px solid ${activeTab === tab ? COLORS.accent : "transparent"}`,
            color: activeTab === tab ? COLORS.accent : COLORS.muted,
            fontSize: 13, fontWeight: 600, cursor: "pointer", textTransform: "capitalize",
          }}>
            {tab}
          </button>
        ))}
      </div>

      <div style={{ padding: "16px" }}>
        {activeTab === "services" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {barber.services.map(s => (
              <div key={s.name} style={{
                display: "flex", justifyContent: "space-between", alignItems: "center",
                padding: "14px", background: COLORS.white,
                border: `1px solid ${COLORS.border}`, borderRadius: 12,
              }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.dark }}>{s.name}</div>
                  <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>⏱ {s.duration}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontWeight: 700, color: COLORS.dark }}>₦{s.price.toLocaleString()}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "portfolio" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6, marginBottom: 12 }}>
              {[...Array(6)].map((_, i) => (
                <div key={i} style={{
                  aspectRatio: "1", borderRadius: 10,
                  background: `${barber.color}${15 + i * 8}`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 28,
                }}>
                  ✂
                </div>
              ))}
            </div>
            <div style={{ textAlign: "center", fontSize: 12, color: COLORS.muted }}>Portfolio photos from verified client results</div>
          </div>
        )}

        {activeTab === "reviews" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              { name: "Tunde A.", text: "Best fade in Ikeja. Always on time and the lines are clean.", stars: 5, date: "2 days ago" },
              { name: "Femi O.", text: "Booked for my wedding day. The whole squad was fresh.", stars: 5, date: "1 week ago" },
              { name: "David K.", text: "Good skills, reasonable price. Would recommend.", stars: 4, date: "2 weeks ago" },
            ].map(r => (
              <div key={r.name} style={{ padding: 14, background: COLORS.surface, borderRadius: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.dark }}>{r.name}</div>
                  <div style={{ fontSize: 11, color: COLORS.muted }}>{r.date}</div>
                </div>
                <StarRating rating={r.stars} size={12} />
                <div style={{ fontSize: 13, color: COLORS.muted, marginTop: 6, lineHeight: 1.5 }}>{r.text}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: "0 16px 20px", display: "flex", gap: 10 }}>
        <button
          onClick={() => { setBookingBarber(barber); setScreen("booking"); }}
          style={{
            flex: 1, background: COLORS.dark, color: "white",
            border: "none", borderRadius: 14, padding: "16px",
            fontSize: 15, fontWeight: 700, cursor: "pointer",
          }}>
          Book Now
        </button>
        {barber.mobile && (
          <button onClick={() => setScreen("mobile")} style={{
            flex: 1, background: COLORS.accent, color: "white",
            border: "none", borderRadius: 14, padding: "16px",
            fontSize: 15, fontWeight: 700, cursor: "pointer",
          }}>
            Request Mobile
          </button>
        )}
      </div>
    </div>
  );
}

function BookingScreen({ barber, setScreen }) {
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("digital");
  const [showCashWarning, setShowCashWarning] = useState(false);
  const [cashAcknowledged, setCashAcknowledged] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  if (!barber) return null;

  // Mobile barbers: 12% fee + transport fee. In-shop: 10%, no transport.
  const isMobile = barber.mobile;
  const feeRate = isMobile ? 0.12 : 0.10;
  const feeRateLabel = isMobile ? "12%" : "10%";
  // Use a fixed demo transport scenario for in-booking flow (Yaba → Lekki, moderate)
  const demoDistance = 18;
  const demoTraffic = "moderate";
  const transportFee = isMobile && selectedService ? calcTransportFee(demoDistance, demoTraffic) : 0;
  const bookingFee = selectedService ? Math.round(selectedService.price * feeRate) : 0;
  const total = paymentMethod === "digital"
    ? (selectedService?.price || 0) + bookingFee + transportFee
    : bookingFee + transportFee;

  if (confirmed) {
    return (
      <div style={{ padding: "32px 20px 40px", textAlign: "center" }}>
        <div style={{ fontSize: 64, marginBottom: 14 }}>{isMobile ? "🏠" : "✂️"}</div>
        <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark, marginBottom: 6 }}>Booking Confirmed!</div>
        <div style={{ fontSize: 14, color: COLORS.muted, lineHeight: 1.6, marginBottom: 4 }}>
          {selectedService?.name} with {barber.name}
        </div>
        <div style={{ fontSize: 13, color: COLORS.muted, marginBottom: 20 }}>
          {isMobile ? "Mobile visit" : "Saturday, May 24"} · {selectedSlot}
        </div>
        <div style={{ background: COLORS.greenBg, color: COLORS.green, borderRadius: 12, padding: "12px 20px", fontSize: 13, fontWeight: 600, marginBottom: 12 }}>
          ✓ {paymentMethod === "digital" ? "Escrow payment secured" : "Booking fee collected — cash at service"}
        </div>
        {isMobile && (
          <div style={{ background: "#EFF6FF", borderRadius: 12, padding: "12px 16px", fontSize: 12, color: "#1D4ED8", marginBottom: 12, textAlign: "left" }}>
            <div style={{ fontWeight: 700, marginBottom: 4 }}>📍 GPS Dispatch Active</div>
            <div style={{ marginBottom: 2 }}>Transport fee paid: ₦{transportFee.toLocaleString()}</div>
            <div style={{ color: "#60A5FA" }}>₦{Math.round(transportFee * 0.8).toLocaleString()} goes to barber · ₦{Math.round(transportFee * 0.2).toLocaleString()} logistics margin</div>
          </div>
        )}
        <div style={{ background: COLORS.accentLight, borderRadius: 12, padding: "10px 16px", fontSize: 12, color: COLORS.accentDark, marginBottom: 20 }}>
          🏆 +{paymentMethod === "digital" ? "20" : "10"} TRIM Points earned
        </div>
        <button onClick={() => setScreen("bookings")} style={{
          background: COLORS.dark, color: "white", border: "none",
          borderRadius: 14, padding: "14px 32px", fontSize: 15, fontWeight: 700, cursor: "pointer",
        }}>
          View My Bookings
        </button>
      </div>
    );
  }

  if (showCashWarning && !cashAcknowledged) {
    return (
      <div style={{ padding: "0 16px" }}>
        <div style={{ paddingTop: 24, paddingBottom: 16 }}>
          <div style={{ background: "#FEF3C7", border: "1px solid #F59E0B", borderRadius: 8, padding: "4px 10px", display: "inline-block", fontSize: 11, fontWeight: 700, color: "#92400E", marginBottom: 12 }}>
            ⚠ IMPORTANT
          </div>
          <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.dark }}>Cash Payment Limitations</div>
        </div>
        <div style={{ background: "#FFFBEB", border: `1px solid #F59E0B`, borderRadius: 14, padding: 16, marginBottom: 16, fontSize: 13, lineHeight: 1.7, color: COLORS.dark }}>
          <p>By choosing to pay in <strong>cash</strong>, you are entering into a direct transaction with the service provider. <strong>TRIM's escrow protection does not cover cash payments.</strong></p>
          <p style={{ marginTop: 10 }}>If you pay cash and are not satisfied, TRIM <strong>cannot refund the cash</strong> you paid. TRIM's only action is a platform-level investigation.</p>
          <p style={{ marginTop: 10 }}>For full financial protection — including refunds and dispute resolution — use <strong>TRIM Wallet (Digital)</strong>. Digital payment earns <strong>2× TRIM Points</strong>.</p>
          <p style={{ marginTop: 10, fontSize: 12, color: COLORS.muted }}>The booking fee of ₦{bookingFee.toLocaleString()} is non-refundable after the appointment window.</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => { setPaymentMethod("digital"); setShowCashWarning(false); }} style={{
            flex: 1, background: COLORS.dark, color: "white", border: "none",
            borderRadius: 14, padding: 14, fontSize: 14, fontWeight: 700, cursor: "pointer",
          }}>
            ← Switch to Digital
          </button>
          <button onClick={() => { setCashAcknowledged(true); setShowCashWarning(false); }} style={{
            flex: 1, background: "#F59E0B", color: "white", border: "none",
            borderRadius: 14, padding: 14, fontSize: 13, fontWeight: 700, cursor: "pointer",
          }}>
            I Understand — Cash
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: "0 16px", paddingBottom: 8 }}>
      <div style={{ paddingTop: 20, paddingBottom: 16, display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={() => step > 1 ? setStep(step - 1) : setScreen("barberProfile")} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", padding: 0 }}>
          ←
        </button>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.dark }}>Book Appointment</div>
          <div style={{ fontSize: 12, color: COLORS.muted }}>with {barber.name}</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 24 }}>
        {[1, 2, 3].map(s => (
          <div key={s} style={{ flex: 1 }}>
            <div style={{ height: 4, borderRadius: 2, background: s <= step ? COLORS.accent : COLORS.border }} />
            <div style={{ fontSize: 10, color: s <= step ? COLORS.accent : COLORS.muted, marginTop: 4, textAlign: "center" }}>
              {["Service", "Schedule", "Payment"][s - 1]}
            </div>
          </div>
        ))}
      </div>

      {step === 1 && (
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.dark, marginBottom: 12 }}>Select a Service</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {barber.services.map(s => (
              <div key={s.name} onClick={() => setSelectedService(s)} style={{
                padding: 14, border: `2px solid ${selectedService?.name === s.name ? COLORS.accent : COLORS.border}`,
                borderRadius: 12, cursor: "pointer", background: selectedService?.name === s.name ? COLORS.accentLight : COLORS.white,
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.dark }}>{s.name}</div>
                  <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>⏱ {s.duration}</div>
                </div>
                <div style={{ fontWeight: 700, color: COLORS.dark }}>₦{s.price.toLocaleString()}</div>
              </div>
            ))}
          </div>
          <button
            disabled={!selectedService}
            onClick={() => setStep(2)}
            style={{
              width: "100%", marginTop: 20, background: selectedService ? COLORS.dark : COLORS.border,
              color: selectedService ? "white" : COLORS.muted,
              border: "none", borderRadius: 14, padding: 16, fontSize: 15, fontWeight: 700, cursor: selectedService ? "pointer" : "not-allowed",
            }}>
            Next: Choose Time →
          </button>
        </div>
      )}

      {step === 2 && (
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.dark, marginBottom: 4 }}>Choose Date & Time</div>
          <div style={{ fontSize: 12, color: COLORS.muted, marginBottom: 16 }}>Available slots for Saturday, May 24</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {barber.slots.map(slot => (
              <div key={slot} onClick={() => setSelectedSlot(slot)} style={{
                padding: "14px", textAlign: "center",
                border: `2px solid ${selectedSlot === slot ? COLORS.accent : COLORS.border}`,
                borderRadius: 12, cursor: "pointer",
                background: selectedSlot === slot ? COLORS.accentLight : COLORS.white,
                fontWeight: 600, color: selectedSlot === slot ? COLORS.accentDark : COLORS.dark,
              }}>
                {slot}
              </div>
            ))}
          </div>
          <div style={{ marginTop: 16, padding: 12, background: COLORS.surface, borderRadius: 10, fontSize: 12, color: COLORS.muted }}>
            ⏱ Estimated wait time: {barber.wait} · SMS reminder sent 2hrs before
          </div>
          <button
            disabled={!selectedSlot}
            onClick={() => setStep(3)}
            style={{
              width: "100%", marginTop: 16,
              background: selectedSlot ? COLORS.dark : COLORS.border,
              color: selectedSlot ? "white" : COLORS.muted,
              border: "none", borderRadius: 14, padding: 16, fontSize: 15, fontWeight: 700, cursor: selectedSlot ? "pointer" : "not-allowed",
            }}>
            Next: Payment →
          </button>
        </div>
      )}

      {step === 3 && (
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.dark, marginBottom: 16 }}>Review & Pay</div>

          {isMobile && (
            <div style={{ background: "#EFF6FF", borderRadius: 10, padding: "10px 14px", marginBottom: 14, display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ fontSize: 18 }}>🏠</span>
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: "#1D4ED8" }}>Mobile Visit · Transport fee included</div>
                <div style={{ fontSize: 11, color: "#60A5FA" }}>
                  {demoDistance}km · {TRAFFIC_MULTIPLIERS[demoTraffic].label} traffic ({TRAFFIC_MULTIPLIERS[demoTraffic].badge}) · 80% paid to barber
                </div>
              </div>
            </div>
          )}

          <div style={{ background: COLORS.surface, borderRadius: 14, padding: 16, marginBottom: 16 }}>
            <div style={{ fontWeight: 700, marginBottom: 10, fontSize: 14, color: COLORS.dark }}>Booking Summary</div>
            {[
              { label: "Service", value: selectedService?.name },
              { label: "Barber", value: barber.name },
              { label: "Time", value: isMobile ? `Today · ${selectedSlot}` : `May 24 · ${selectedSlot}` },
              { label: "Service Price", value: `₦${selectedService?.price.toLocaleString()}` },
              { label: `Platform Booking Fee (${feeRateLabel})`, value: `₦${bookingFee.toLocaleString()}` },
              ...(isMobile ? [{
                label: `Transport Fee (${demoDistance}km · ${TRAFFIC_MULTIPLIERS[demoTraffic].label})`,
                value: `₦${transportFee.toLocaleString()}`,
                highlight: true,
              }] : []),
            ].map(r => (
              <div key={r.label} style={{
                display: "flex", justifyContent: "space-between", padding: "6px 0",
                borderBottom: `1px solid ${COLORS.border}`, fontSize: 13,
              }}>
                <span style={{ color: r.highlight ? "#1D4ED8" : COLORS.muted }}>{r.label}</span>
                <span style={{ fontWeight: 600, color: r.highlight ? "#1D4ED8" : COLORS.dark }}>{r.value}</span>
              </div>
            ))}
            {isMobile && (
              <div style={{ marginTop: 10, padding: "8px 10px", background: "#F0F9FF", borderRadius: 8, fontSize: 11, color: "#0369A1" }}>
                Transport split: ₦{Math.round(transportFee * 0.8).toLocaleString()} → barber (T+1) · ₦{Math.round(transportFee * 0.2).toLocaleString()} → TRIM logistics
              </div>
            )}
          </div>

          <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.dark, marginBottom: 10 }}>Payment Method</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
            {[
              {
                id: "digital", icon: "💳", label: "TRIM Wallet (Digital)",
                sub: isMobile
                  ? "Full escrow protection · 2× TRIM Points · Balance: ₦12,500"
                  : "Full escrow protection · 2× TRIM Points · Balance: ₦12,500",
                charge: isMobile
                  ? `₦${((selectedService?.price || 0) + bookingFee + transportFee).toLocaleString()} now`
                  : `₦${(selectedService?.price || 0).toLocaleString()} now`,
                recommended: true,
              },
              {
                id: "cash", icon: "💵", label: "Pay barber in cash",
                sub: isMobile
                  ? "Booking fee + transport always paid digitally — service in cash at visit"
                  : "Limited protection — booking fee only charged now",
                charge: isMobile
                  ? `₦${(bookingFee + transportFee).toLocaleString()} now (fee + transport)`
                  : `₦${bookingFee.toLocaleString()} booking fee only`,
              },
            ].map(pm => (
              <div key={pm.id} onClick={() => {
                setPaymentMethod(pm.id);
                if (pm.id === "cash" && !cashAcknowledged) setShowCashWarning(true);
              }} style={{
                padding: 14, border: `2px solid ${paymentMethod === pm.id ? COLORS.accent : COLORS.border}`,
                borderRadius: 12, cursor: "pointer",
                background: paymentMethod === pm.id ? COLORS.accentLight : COLORS.white,
              }}>
                <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                  <span style={{ fontSize: 22 }}>{pm.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.dark, display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                      {pm.label}
                      {pm.recommended && <Badge>Recommended</Badge>}
                    </div>
                    <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>{pm.sub}</div>
                    <div style={{ marginTop: 6, fontSize: 12, fontWeight: 600, color: paymentMethod === pm.id ? COLORS.accentDark : COLORS.muted }}>
                      Charged: {pm.charge}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {isMobile && paymentMethod === "cash" && (
            <div style={{ background: "#FFF7ED", border: "1px solid #FED7AA", borderRadius: 10, padding: "10px 12px", marginBottom: 12, fontSize: 12, color: "#92400E" }}>
              ⚠ Transport fee (₦{transportFee.toLocaleString()}) is always charged digitally — it is never collected by the barber in cash. §5.6.3
            </div>
          )}

          <div style={{ background: COLORS.dark, borderRadius: 14, padding: 16, color: "white", marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: isMobile ? 8 : 0 }}>
              <div>
                <div style={{ fontSize: 12, opacity: 0.7 }}>Total charged now</div>
                <div style={{ fontSize: 22, fontWeight: 800 }}>₦{total.toLocaleString()}</div>
              </div>
              <div style={{ fontSize: 12, opacity: 0.7, textAlign: "right" }}>
                +{paymentMethod === "digital" ? "20" : "10"}<br />TRIM Points
              </div>
            </div>
            {isMobile && paymentMethod === "cash" && (
              <div style={{ borderTop: "1px solid rgba(255,255,255,0.15)", paddingTop: 8, fontSize: 11, opacity: 0.7 }}>
                + ₦{(selectedService?.price || 0).toLocaleString()} cash to barber at visit
              </div>
            )}
          </div>

          <button onClick={() => setConfirmed(true)} style={{
            width: "100%", background: COLORS.accent, color: "white",
            border: "none", borderRadius: 14, padding: 16, fontSize: 15, fontWeight: 700, cursor: "pointer",
          }}>
            Confirm Booking →
          </button>
        </div>
      )}
    </div>
  );
}

function TransportBreakdown({ servicePrice, distanceKm, trafficKey, serviceName }) {
  const transportFee = calcTransportFee(distanceKm, trafficKey);
  const bookingFee = Math.round(servicePrice * 0.12); // 12% for mobile
  const totalDigital = servicePrice + bookingFee + transportFee;
  const totalCash = bookingFee + transportFee;
  const providerTravel = Math.round(transportFee * 0.8);
  const trimLogistics = transportFee - providerTravel;
  const tc = TRAFFIC_MULTIPLIERS[trafficKey];

  return (
    <div style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, overflow: "hidden" }}>
      <div style={{ background: COLORS.surface, padding: "12px 14px", borderBottom: `1px solid ${COLORS.border}` }}>
        <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.dark }}>Price Breakdown</div>
        <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>
          {distanceKm}km · {tc.label} traffic ·{" "}
          <span style={{ background: tc.bg, color: tc.color, padding: "1px 6px", borderRadius: 8, fontWeight: 600 }}>
            {tc.badge}
          </span>
        </div>
      </div>

      <div style={{ padding: "12px 14px" }}>
        {[
          { label: serviceName || "Mobile Haircut", value: `₦${servicePrice.toLocaleString()}`, sub: null },
          { label: "Platform Booking Fee (12%)", value: `₦${bookingFee.toLocaleString()}`, sub: "TRIM commission · non-refundable" },
          {
            label: `Transport Fee (${distanceKm}km × ₦${BASE_RATE} × ${tc.value})`,
            value: `₦${transportFee.toLocaleString()}`,
            sub: distanceKm * BASE_RATE * tc.value < MIN_FEE
              ? `Floored to minimum ₦${MIN_FEE}`
              : distanceKm * BASE_RATE * tc.value > MAX_FEE
              ? `Capped at maximum ₦${MAX_FEE.toLocaleString()}`
              : `₦${Math.round(distanceKm * BASE_RATE * tc.value).toLocaleString()} · within range`,
            highlight: true,
          },
        ].map((row, i) => (
          <div key={i} style={{
            display: "flex", justifyContent: "space-between", alignItems: "flex-start",
            padding: "8px 0",
            borderBottom: i < 2 ? `1px solid ${COLORS.border}` : "none",
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, color: COLORS.dark, fontWeight: row.highlight ? 600 : 400 }}>{row.label}</div>
              {row.sub && <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 1 }}>{row.sub}</div>}
            </div>
            <div style={{
              fontSize: 14, fontWeight: 700,
              color: row.highlight ? "#1D4ED8" : COLORS.dark,
              marginLeft: 12, whiteSpace: "nowrap",
            }}>
              {row.value}
            </div>
          </div>
        ))}
      </div>

      <div style={{ background: COLORS.dark, padding: "12px 14px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.7)" }}>Total (Digital payment)</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: "white" }}>₦{totalDigital.toLocaleString()}</div>
        </div>
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>
          OR: Pay ₦{totalCash.toLocaleString()} now · Pay ₦{servicePrice.toLocaleString()} cash to barber at service
        </div>
      </div>

      <div style={{ padding: "10px 14px", background: "#EFF6FF", borderTop: `1px solid ${COLORS.border}` }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: "#1D4ED8", marginBottom: 4 }}>Transport Fee Split (§5.6.4)</div>
        <div style={{ display: "flex", gap: 8 }}>
          <div style={{ flex: 4, background: "#BFDBFE", borderRadius: 6, padding: "6px 8px" }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#1E40AF" }}>₦{providerTravel.toLocaleString()}</div>
            <div style={{ fontSize: 10, color: "#3B82F6" }}>80% → Provider (T+1)</div>
          </div>
          <div style={{ flex: 1, background: "#DBEAFE", borderRadius: 6, padding: "6px 8px" }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#1E40AF" }}>₦{trimLogistics.toLocaleString()}</div>
            <div style={{ fontSize: 10, color: "#3B82F6" }}>20% → TRIM</div>
          </div>
        </div>
        <div style={{ fontSize: 10, color: "#60A5FA", marginTop: 4 }}>
          Covers Maps API, GPS tracking & dispatch infrastructure
        </div>
      </div>
    </div>
  );
}

function MobileBarberScreen({ setScreen }) {
  const [step, setStep] = useState(1); // 1=address+service, 2=distance+traffic, 3=confirm
  const [address, setAddress] = useState("");
  const [service, setService] = useState("");
  const [servicePrice, setServicePrice] = useState(4000);
  const [time, setTime] = useState("");
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [customDistance, setCustomDistance] = useState(10);
  const [trafficKey, setTrafficKey] = useState("moderate");
  const [submitted, setSubmitted] = useState(false);

  const distanceKm = selectedRoute ? selectedRoute.distance : customDistance;
  const transportFee = calcTransportFee(distanceKm, trafficKey);
  const bookingFee = Math.round(servicePrice * 0.12);

  const MOBILE_SERVICES = [
    { name: "Home Haircut", price: 4000 },
    { name: "Home Fade + Beard", price: 5500 },
    { name: "Shape-Up Only", price: 2500 },
    { name: "Event Grooming Package", price: 8000 },
  ];

  if (submitted) {
    return (
      <div style={{ padding: "40px 16px", textAlign: "center" }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>🏠</div>
        <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark, marginBottom: 6 }}>Barber on the Way!</div>
        <div style={{ fontSize: 14, color: COLORS.muted, marginBottom: 20 }}>Chisom Mobile Pro dispatched to your location</div>
        <div style={{ background: "#EFF6FF", borderRadius: 14, padding: 16, marginBottom: 16, textAlign: "left" }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: "#1D4ED8", marginBottom: 8 }}>📍 Live GPS Tracking Active</div>
          <div style={{ fontSize: 12, color: "#3B82F6", marginBottom: 4 }}>ETA: ~{Math.round(distanceKm * 2.5 + 5)} minutes · {distanceKm}km away</div>
          <div style={{ fontSize: 12, color: "#60A5FA" }}>You'll receive an SMS when the barber is 5 minutes away</div>
        </div>
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 14, marginBottom: 20, textAlign: "left" }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.dark, marginBottom: 8 }}>Payment Collected</div>
          {[
            { label: "Booking fee (12%)", value: `₦${bookingFee.toLocaleString()}` },
            { label: "Transport fee", value: `₦${transportFee.toLocaleString()}` },
          ].map(r => (
            <div key={r.label} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
              <span style={{ color: COLORS.muted }}>{r.label}</span>
              <span style={{ fontWeight: 600, color: COLORS.dark }}>{r.value}</span>
            </div>
          ))}
          <div style={{ borderTop: `1px solid ${COLORS.border}`, marginTop: 6, paddingTop: 6, display: "flex", justifyContent: "space-between", fontSize: 13 }}>
            <span style={{ fontWeight: 600, color: COLORS.dark }}>Charged now</span>
            <span style={{ fontWeight: 800, color: COLORS.dark }}>₦{(bookingFee + transportFee).toLocaleString()}</span>
          </div>
        </div>
        <button onClick={() => setScreen("home")} style={{
          background: COLORS.dark, color: "white", border: "none",
          borderRadius: 14, padding: "14px 32px", fontSize: 15, fontWeight: 700, cursor: "pointer",
        }}>
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div style={{ padding: "0 16px", paddingBottom: 24 }}>
      <div style={{ paddingTop: 20, paddingBottom: 12, display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={() => step > 1 ? setStep(step - 1) : setScreen("home")} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", padding: 0 }}>←</button>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.dark }}>Request Mobile Barber</div>
          <div style={{ fontSize: 12, color: COLORS.muted }}>We come to you · Transport fee calculated live</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 20 }}>
        {[1, 2, 3].map(s => (
          <div key={s} style={{ flex: 1 }}>
            <div style={{ height: 4, borderRadius: 2, background: s <= step ? "#3B82F6" : COLORS.border }} />
            <div style={{ fontSize: 10, color: s <= step ? "#3B82F6" : COLORS.muted, marginTop: 3, textAlign: "center" }}>
              {["Location & Service", "Distance & Traffic", "Confirm & Pay"][s - 1]}
            </div>
          </div>
        ))}
      </div>

      {step === 1 && (
        <>
          <div style={{ background: "#EFF6FF", borderRadius: 12, padding: 12, marginBottom: 16, display: "flex", gap: 10, alignItems: "center" }}>
            <span style={{ fontSize: 20 }}>⚡</span>
            <div>
              <div style={{ fontWeight: 600, fontSize: 13, color: "#1D4ED8" }}>3 verified mobile barbers nearby</div>
              <div style={{ fontSize: 11, color: "#3B82F6" }}>All background-checked · Transport fee calculated transparently</div>
            </div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 6 }}>Your Service Address</label>
            <input
              value={address} onChange={e => setAddress(e.target.value)}
              placeholder="e.g. 5 Admiralty Way, Lekki Phase 1"
              style={{ width: "100%", padding: 12, borderRadius: 10, border: `1px solid ${COLORS.border}`, fontSize: 14, boxSizing: "border-box" }}
            />
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              {[
                { label: "🏠 Home", addr: "5 Chevron Drive, Lekki Phase 2" },
                { label: "🏢 Office", addr: "Plot 1684, Sanusi Fafunwa St, VI" },
                { label: "🏨 Hotel", addr: "Eko Hotel, Plot 1415, Adetokunbo Ademola St" },
              ].map(loc => (
                <button key={loc.label} onClick={() => setAddress(loc.addr)} style={{
                  padding: "6px 10px", borderRadius: 20, border: `1px solid ${COLORS.border}`,
                  background: address === loc.addr ? COLORS.accentLight : COLORS.white,
                  fontSize: 11, cursor: "pointer", color: COLORS.muted, whiteSpace: "nowrap",
                }}>
                  {loc.label}
                </button>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 6 }}>Select Service</label>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {MOBILE_SERVICES.map(s => (
                <div key={s.name} onClick={() => { setService(s.name); setServicePrice(s.price); }} style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  padding: "12px 14px",
                  border: `2px solid ${service === s.name ? "#3B82F6" : COLORS.border}`,
                  borderRadius: 10, cursor: "pointer",
                  background: service === s.name ? "#EFF6FF" : COLORS.white,
                }}>
                  <span style={{ fontSize: 13, fontWeight: 500, color: COLORS.dark }}>{s.name}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: COLORS.dark }}>₦{s.price.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 6 }}>Preferred Time</label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {["ASAP", "In 1 hour", "This evening", "Tomorrow morning"].map(t => (
                <div key={t} onClick={() => setTime(t)} style={{
                  padding: 12, textAlign: "center",
                  border: `2px solid ${time === t ? "#3B82F6" : COLORS.border}`,
                  borderRadius: 10, cursor: "pointer",
                  background: time === t ? "#EFF6FF" : COLORS.white,
                  fontSize: 13, fontWeight: 500, color: time === t ? "#1D4ED8" : COLORS.dark,
                }}>
                  {t}
                </div>
              ))}
            </div>
          </div>

          <button
            disabled={!address || !service || !time}
            onClick={() => setStep(2)}
            style={{
              width: "100%", padding: 16, borderRadius: 14,
              background: address && service && time ? "#3B82F6" : COLORS.border,
              color: address && service && time ? "white" : COLORS.muted,
              border: "none", fontSize: 15, fontWeight: 700, cursor: address && service && time ? "pointer" : "not-allowed",
            }}>
            Next: Calculate Transport Fee →
          </button>
        </>
      )}

      {step === 2 && (
        <>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.dark, marginBottom: 10 }}>
              Select Your Scenario
            </div>
            <div style={{ fontSize: 12, color: COLORS.muted, marginBottom: 10 }}>
              In the live app, distance is calculated automatically via Google Maps Distance Matrix.
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {SAMPLE_ROUTES.map(r => {
                const fee = calcTransportFee(r.distance, r.traffic);
                const tc = TRAFFIC_MULTIPLIERS[r.traffic];
                return (
                  <div key={r.label} onClick={() => { setSelectedRoute(r); setCustomDistance(r.distance); setTrafficKey(r.traffic); }} style={{
                    padding: "12px 14px",
                    border: `2px solid ${selectedRoute?.label === r.label ? "#3B82F6" : COLORS.border}`,
                    borderRadius: 12, cursor: "pointer",
                    background: selectedRoute?.label === r.label ? "#EFF6FF" : COLORS.white,
                  }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark }}>{r.label}</div>
                      <div style={{ fontSize: 14, fontWeight: 800, color: "#1D4ED8" }}>₦{fee.toLocaleString()}</div>
                    </div>
                    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                      <span style={{ fontSize: 11, color: COLORS.muted }}>{r.distance}km</span>
                      <span style={{ fontSize: 11, color: COLORS.muted }}>·</span>
                      <span style={{ fontSize: 11, background: tc.bg, color: tc.color, padding: "1px 6px", borderRadius: 8, fontWeight: 600 }}>
                        {tc.label} {tc.badge}
                      </span>
                      <span style={{ fontSize: 11, color: COLORS.muted }}>·</span>
                      <span style={{ fontSize: 10, color: COLORS.muted }}>
                        {r.distance}km × ₦{BASE_RATE} × {tc.value} = ₦{Math.round(r.distance * BASE_RATE * tc.value).toLocaleString()}
                        {r.distance * BASE_RATE * tc.value < MIN_FEE ? ` → floored ₦${MIN_FEE}` : r.distance * BASE_RATE * tc.value > MAX_FEE ? ` → capped ₦${MAX_FEE.toLocaleString()}` : ""}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div style={{ marginBottom: 16, padding: 14, background: COLORS.surface, borderRadius: 12, border: `1px solid ${COLORS.border}` }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.dark, marginBottom: 8 }}>Or enter a custom distance</div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
              <input
                type="range" min={1} max={40} step={1} value={customDistance}
                onChange={e => { setCustomDistance(Number(e.target.value)); setSelectedRoute(null); }}
                style={{ flex: 1 }}
              />
              <span style={{ fontSize: 14, fontWeight: 700, color: COLORS.dark, minWidth: 50 }}>{customDistance} km</span>
            </div>
            <div style={{ fontSize: 12, color: COLORS.muted, marginBottom: 10 }}>Traffic conditions</div>
            <div style={{ display: "flex", gap: 6 }}>
              {Object.entries(TRAFFIC_MULTIPLIERS).map(([key, tc]) => (
                <button key={key} onClick={() => { setTrafficKey(key); setSelectedRoute(null); }} style={{
                  flex: 1, padding: "6px 4px", borderRadius: 8,
                  border: `2px solid ${trafficKey === key && !selectedRoute ? tc.color : COLORS.border}`,
                  background: trafficKey === key && !selectedRoute ? tc.bg : COLORS.white,
                  cursor: "pointer", fontSize: 10, fontWeight: 600,
                  color: trafficKey === key && !selectedRoute ? tc.color : COLORS.muted,
                }}>
                  {tc.label}
                </button>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 16, background: "#F0F9FF", borderRadius: 10, padding: 12, border: "1px solid #BAE6FD" }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#0369A1", marginBottom: 4 }}>Formula (§5.6.2)</div>
            <div style={{ fontFamily: "monospace", fontSize: 12, color: "#0C4A6E", lineHeight: 1.6 }}>
              max(₦{MIN_FEE}, min(d × ₦{BASE_RATE} × multiplier, ₦{MAX_FEE.toLocaleString()}))
            </div>
          </div>

          <button onClick={() => setStep(3)} style={{
            width: "100%", padding: 16, borderRadius: 14,
            background: "#3B82F6", color: "white",
            border: "none", fontSize: 15, fontWeight: 700, cursor: "pointer",
          }}>
            View Full Price Breakdown →
          </button>
        </>
      )}

      {step === 3 && (
        <>
          <div style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center", background: COLORS.surface, borderRadius: 12, padding: 14, marginBottom: 14 }}>
              <Avatar initials="CM" color="#3B82F6" size={48} />
              <div>
                <div style={{ fontWeight: 700, fontSize: 15, color: COLORS.dark }}>Chisom Mobile Pro</div>
                <div style={{ fontSize: 12, color: COLORS.muted }}>⭐ 4.8 · 189 reviews · {distanceKm}km from you</div>
                <div style={{ fontSize: 12, color: COLORS.green, marginTop: 2 }}>✓ KYC Verified · Mobile Zone Cleared</div>
              </div>
            </div>

            <TransportBreakdown
              servicePrice={servicePrice}
              distanceKm={distanceKm}
              trafficKey={trafficKey}
              serviceName={service}
            />
          </div>

          <div style={{ background: "#FFF7ED", borderRadius: 10, padding: 12, marginBottom: 16, border: "1px solid #FED7AA", fontSize: 12, color: "#92400E" }}>
            <strong>Note:</strong> The transport fee is always paid digitally at booking — even if you choose to pay for the service in cash. The barber receives 80% (₦{Math.round(transportFee * 0.8).toLocaleString()}) as travel compensation in their T+1 settlement.
          </div>

          <button onClick={() => setSubmitted(true)} style={{
            width: "100%", padding: 16, borderRadius: 14,
            background: "#3B82F6", color: "white",
            border: "none", fontSize: 15, fontWeight: 700, cursor: "pointer",
          }}>
            Confirm & Pay ₦{(bookingFee + transportFee).toLocaleString()} Now →
          </button>
          <div style={{ textAlign: "center", fontSize: 11, color: COLORS.muted, marginTop: 8 }}>
            Booking fee + transport charged now · Service amount at appointment
          </div>
        </>
      )}
    </div>
  );
}

function BookingsScreen() {
  const bookings = [
    { barber: "Biodun Cuts", service: "Fade + Beard Trim", date: "May 24, 9:00 AM", status: "Upcoming", statusColor: COLORS.green, statusBg: COLORS.greenBg },
    { barber: "Chisom Mobile Pro", service: "Home Haircut", date: "May 18, 11:00 AM", status: "Completed", statusColor: COLORS.muted, statusBg: COLORS.surface },
    { barber: "Queens Salon Ikeja", service: "Natural Wash & Style", date: "May 10, 3:00 PM", status: "Completed", statusColor: COLORS.muted, statusBg: COLORS.surface },
  ];

  return (
    <div style={{ padding: "0 16px", paddingBottom: 8 }}>
      <div style={{ paddingTop: 24, paddingBottom: 16 }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark }}>My Bookings</div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {bookings.map((b, i) => (
          <div key={i} style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 16, padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <div style={{ fontWeight: 700, fontSize: 15, color: COLORS.dark }}>{b.barber}</div>
              <span style={{ fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 20, background: b.statusBg, color: b.statusColor }}>
                {b.status}
              </span>
            </div>
            <div style={{ fontSize: 13, color: COLORS.muted }}>{b.service}</div>
            <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 4 }}>📅 {b.date}</div>
            {b.status === "Completed" && (
              <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
                <button style={{ flex: 1, padding: "8px", borderRadius: 8, background: COLORS.accentLight, color: COLORS.accentDark, border: "none", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                  Rate & Review
                </button>
                <button style={{ flex: 1, padding: "8px", borderRadius: 8, background: COLORS.surface, color: COLORS.muted, border: `1px solid ${COLORS.border}`, fontSize: 12, cursor: "pointer" }}>
                  Rebook
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function MarketplaceScreen({ setScreen, cart, setCart }) {
  const categories = ["All", "Clippers", "Beard Care", "Tools", "Kits"];
  const [cat, setCat] = useState("All");

  const filtered = PRODUCTS.filter(p => cat === "All" || p.category === cat);
  const totalItems = cart.reduce((a, c) => a + c.qty, 0);

  const addToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id);
      if (existing) return prev.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...product, qty: 1 }];
    });
    // Immediately navigate to cart
    setScreen("cart");
  };

  return (
    <div style={{ padding: "0 16px", paddingBottom: 8 }}>
      <div style={{ paddingTop: 24, paddingBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark }}>Marketplace</div>
          <div style={{ fontSize: 13, color: COLORS.muted }}>Quality grooming products</div>
        </div>
        <div style={{ position: "relative", cursor: "pointer" }} onClick={() => totalItems > 0 && setScreen("cart")}>
          <div style={{ fontSize: 26 }}>🛍</div>
          {totalItems > 0 && (
            <div style={{ position: "absolute", top: -4, right: -4, width: 18, height: 18, background: COLORS.accent, borderRadius: "50%", fontSize: 10, fontWeight: 800, color: "white", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {totalItems}
            </div>
          )}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 8, marginBottom: 16, scrollbarWidth: "none" }}>
        {categories.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{
            flexShrink: 0, padding: "7px 14px", borderRadius: 20,
            border: `1px solid ${cat === c ? COLORS.accent : COLORS.border}`,
            background: cat === c ? COLORS.accent : COLORS.white,
            color: cat === c ? "white" : COLORS.muted,
            fontSize: 13, fontWeight: 500, cursor: "pointer",
          }}>
            {c}
          </button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {filtered.map(p => {
          const inCart = cart.find(i => i.id === p.id);
          return (
            <div key={p.id} style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, padding: 14 }}>
              <div style={{ height: 90, background: COLORS.surface, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, marginBottom: 10 }}>
                {p.category === "Clippers" ? "💈" : p.category === "Beard Care" ? "🧴" : p.category === "Kits" ? "🎒" : "🪒"}
              </div>
              <div style={{ fontWeight: 600, fontSize: 13, color: COLORS.dark, marginBottom: 2 }}>{p.name}</div>
              <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 6 }}>{p.seller}</div>
              <StarRating rating={p.rating} size={11} />
              <div style={{ marginTop: 8, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark }}>₦{p.price.toLocaleString()}</span>
                {inCart ? (
                  <button onClick={() => setScreen("cart")} style={{ background: COLORS.green, color: "white", border: "none", borderRadius: 8, padding: "5px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                    In Cart ✓
                  </button>
                ) : (
                  <button onClick={() => addToCart(p)} style={{ background: COLORS.dark, color: "white", border: "none", borderRadius: 8, padding: "5px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                    Add +
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CartScreen({ setScreen, cart, setCart }) {
  const [checkingOut, setCheckingOut] = useState(false);
  const [ordered, setOrdered] = useState(false);

  const updateQty = (id, delta) => {
    setCart(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(0, i.qty + delta) } : i).filter(i => i.qty > 0));
  };
  const removeItem = (id) => setCart(prev => prev.filter(i => i.id !== id));

  const subtotal = cart.reduce((a, i) => a + i.price * i.qty, 0);
  const delivery = 1500;
  const total = subtotal + (cart.length > 0 ? delivery : 0);

  if (ordered) return (
    <div style={{ padding: "60px 24px", textAlign: "center" }}>
      <div style={{ fontSize: 64, marginBottom: 16 }}>📦</div>
      <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark, marginBottom: 8 }}>Order Placed!</div>
      <div style={{ fontSize: 14, color: COLORS.muted, lineHeight: 1.6, marginBottom: 20 }}>
        Your order of ₦{total.toLocaleString()} has been confirmed.<br />
        Estimated delivery: 2–3 business days.
      </div>
      <div style={{ background: "#EFF6FF", borderRadius: 12, padding: 14, marginBottom: 20, fontSize: 12, color: "#1D4ED8", textAlign: "left" }}>
        <div style={{ fontWeight: 700, marginBottom: 4 }}>📋 Admin Visibility</div>
        This order is now visible on the TRIM Admin Dashboard for fulfilment oversight and quality control.
      </div>
      <button onClick={() => { setCart([]); setScreen("marketplace"); }} style={{ background: COLORS.dark, color: "white", border: "none", borderRadius: 14, padding: "14px 32px", fontSize: 15, fontWeight: 700, cursor: "pointer" }}>
        Back to Shop
      </button>
    </div>
  );

  return (
    <div style={{ padding: "0 16px", paddingBottom: 32 }}>
      <div style={{ paddingTop: 20, paddingBottom: 14, display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={() => setScreen("marketplace")} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", padding: 0 }}>←</button>
        <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.dark }}>Your Cart</div>
        {cart.length > 0 && (
          <span style={{ fontSize: 12, background: COLORS.accentLight, color: COLORS.accentDark, padding: "3px 8px", borderRadius: 10, fontWeight: 600 }}>
            {cart.reduce((a, i) => a + i.qty, 0)} items
          </span>
        )}
      </div>

      {cart.length === 0 ? (
        <div style={{ textAlign: "center", padding: "60px 0" }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🛍</div>
          <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.dark, marginBottom: 6 }}>Your cart is empty</div>
          <div style={{ fontSize: 13, color: COLORS.muted, marginBottom: 20 }}>Add some products from the marketplace</div>
          <button onClick={() => setScreen("marketplace")} style={{ background: COLORS.accent, color: "white", border: "none", borderRadius: 12, padding: "12px 24px", fontWeight: 700, cursor: "pointer" }}>
            Browse Products
          </button>
        </div>
      ) : (
        <>
          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
            {cart.map(item => (
              <div key={item.id} style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, padding: 14, display: "flex", gap: 12, alignItems: "center" }}>
                <div style={{ width: 52, height: 52, borderRadius: 10, background: COLORS.surface, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>
                  {item.category === "Clippers" ? "💈" : item.category === "Beard Care" ? "🧴" : item.category === "Kits" ? "🎒" : "🪒"}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.dark }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: COLORS.muted }}>{item.seller}</div>
                  <div style={{ fontSize: 14, fontWeight: 800, color: COLORS.dark, marginTop: 4 }}>
                    ₦{(item.price * item.qty).toLocaleString()}
                    {item.qty > 1 && <span style={{ fontSize: 11, fontWeight: 400, color: COLORS.muted }}> (₦{item.price.toLocaleString()} × {item.qty})</span>}
                  </div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, flexShrink: 0 }}>
                  {/* Qty controls */}
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <button onClick={() => updateQty(item.id, -1)} style={{ width: 28, height: 28, borderRadius: "50%", border: `1px solid ${COLORS.border}`, background: COLORS.white, fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: COLORS.dark }}>−</button>
                    <span style={{ fontSize: 14, fontWeight: 700, color: COLORS.dark, minWidth: 16, textAlign: "center" }}>{item.qty}</span>
                    <button onClick={() => updateQty(item.id, 1)} style={{ width: 28, height: 28, borderRadius: "50%", border: `1px solid ${COLORS.border}`, background: COLORS.white, fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: COLORS.dark }}>+</button>
                  </div>
                  {/* Remove */}
                  <button onClick={() => removeItem(item.id)} style={{ fontSize: 11, color: COLORS.red, background: "none", border: "none", cursor: "pointer", fontWeight: 600, padding: 0 }}>
                    Remove ✕
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Order summary */}
          <div style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, padding: 16, marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark, marginBottom: 10 }}>Order Summary</div>
            {[
              { label: "Subtotal", value: `₦${subtotal.toLocaleString()}` },
              { label: "Delivery", value: `₦${delivery.toLocaleString()}` },
            ].map(r => (
              <div key={r.label} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                <span style={{ color: COLORS.muted }}>{r.label}</span>
                <span style={{ fontWeight: 500, color: COLORS.dark }}>{r.value}</span>
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 16, fontWeight: 800, paddingTop: 10, color: COLORS.dark }}>
              <span>Total</span>
              <span>₦{total.toLocaleString()}</span>
            </div>
          </div>

          <button onClick={() => setOrdered(true)} style={{ width: "100%", padding: 16, borderRadius: 14, background: COLORS.accent, color: "white", border: "none", fontSize: 15, fontWeight: 700, cursor: "pointer" }}>
            Proceed to Checkout →
          </button>
          <button onClick={() => setScreen("marketplace")} style={{ width: "100%", marginTop: 8, padding: 12, borderRadius: 14, border: `1px solid ${COLORS.border}`, background: COLORS.white, color: COLORS.muted, fontSize: 14, cursor: "pointer" }}>
            ← Continue Shopping
          </button>
        </>
      )}
    </div>
  );
}

// ─── ADMIN DASHBOARD ─────────────────────────────────────────────────────────
function AdminDashboardScreen({ setScreen }) {
  const [tab, setTab] = useState("orders"); // orders | bookings | providers | disputes

  const ORDERS = [
    { id: "ORD-001", customer: "Emeka Okafor",    item: "Wahl Magic Clip",         qty: 1, total: 48000, status: "shipped",    source: "TRIM Internal", tracking: "NG1234567890" },
    { id: "ORD-002", customer: "Tunde Adeyemi",   item: "Beard Conditioning Oil",  qty: 2, total: 7000,  status: "processing", source: "Provider: Biodun Cuts", tracking: null },
    { id: "ORD-003", customer: "Femi Okonkwo",    item: "Starter Barber Kit",      qty: 1, total: 85000, status: "delivered",  source: "TRIM Internal", tracking: "NG0987654321" },
    { id: "ORD-004", customer: "David Kingsley",  item: "Fade Brush Set",          qty: 3, total: 6600,  status: "pending",    source: "Provider: Queens Salon", tracking: null },
    { id: "ORD-005", customer: "Chukwu Emeka",    item: "Pomade (Medium Hold)",    qty: 2, total: 3600,  status: "processing", source: "Provider: Biodun Cuts", tracking: null },
  ];

  const BOOKINGS = [
    { id: "BK-201", customer: "Emeka Okafor",   provider: "Biodun Cuts",   service: "Fade + Beard", amount: 3500, status: "confirmed", flag: null },
    { id: "BK-202", customer: "Rasheed Bello",  provider: "Unassigned",    service: "Classic Cut",  amount: 2500, status: "declined",  flag: "reassignment_pending" },
    { id: "BK-203", customer: "Sade Adeyemi",   provider: "Queens Salon",  service: "Knotless Braids", amount: 12000, status: "confirmed", flag: null },
    { id: "BK-204", customer: "Kunle Martins",  provider: "Emeka Razors",  service: "Hot Towel Shave", amount: 4000, status: "pending",  flag: null },
  ];

  const statusColor = { shipped: "#1D4ED8", processing: COLORS.accent, delivered: COLORS.green, pending: COLORS.muted, confirmed: COLORS.green, declined: COLORS.red };
  const statusBg    = { shipped: "#EFF6FF", processing: COLORS.accentLight, delivered: COLORS.greenBg, pending: COLORS.surface, confirmed: COLORS.greenBg, declined: COLORS.redBg };

  return (
    <div style={{ padding: "0 16px 32px" }}>
      {/* Header */}
      <div style={{ paddingTop: 24, paddingBottom: 16, display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={() => setScreen("home")} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", padding: 0 }}>←</button>
        <div>
          <div style={{ fontSize: 20, fontWeight: 800, color: COLORS.dark }}>Admin Dashboard</div>
          <div style={{ fontSize: 12, color: COLORS.muted }}>End-to-end fulfilment oversight</div>
        </div>
        <span style={{ marginLeft: "auto", fontSize: 11, background: "#FEE2E2", color: COLORS.red, padding: "3px 8px", borderRadius: 8, fontWeight: 700 }}>
          Admin Access
        </span>
      </div>

      {/* Summary cards */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 8, marginBottom: 20 }}>
        {[
          { label: "Orders",    value: ORDERS.length,    color: "#1D4ED8", bg: "#EFF6FF" },
          { label: "Bookings",  value: BOOKINGS.length,  color: "#7C3AED", bg: "#F5F3FF" },
          { label: "Disputes",  value: 1,                color: COLORS.red, bg: COLORS.redBg },
          { label: "Providers", value: 4,                color: COLORS.green, bg: COLORS.greenBg },
        ].map(s => (
          <div key={s.label} style={{ background: s.bg, borderRadius: 12, padding: "10px 6px", textAlign: "center" }}>
            <div style={{ fontWeight: 800, fontSize: 18, color: s.color }}>{s.value}</div>
            <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 1 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: `1px solid ${COLORS.border}`, marginBottom: 16 }}>
        {[
          { id: "orders",    label: "🛍 Orders" },
          { id: "bookings",  label: "📅 Bookings" },
          { id: "providers", label: "💈 Providers" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex: 1, padding: "10px 4px", background: "none", border: "none",
            borderBottom: `2.5px solid ${tab === t.id ? COLORS.dark : "transparent"}`,
            color: tab === t.id ? COLORS.dark : COLORS.muted,
            fontSize: 12, fontWeight: 700, cursor: "pointer",
          }}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "orders" && (
        <div>
          <div style={{ fontSize: 12, color: COLORS.muted, marginBottom: 12 }}>
            All orders across TRIM internal listings and provider-listed items — full fulfilment visibility.
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {ORDERS.map(o => (
              <div key={o.id} style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, padding: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.muted }}>{o.id}</div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.dark }}>{o.item}</div>
                    <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 1 }}>
                      {o.customer} · Qty {o.qty} · ₦{o.total.toLocaleString()}
                    </div>
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 10, background: statusBg[o.status], color: statusColor[o.status] }}>
                    {o.status.charAt(0).toUpperCase() + o.status.slice(1)}
                  </span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 11 }}>
                  <span style={{ color: "#7C3AED", fontWeight: 500, background: "#F5F3FF", padding: "2px 8px", borderRadius: 6 }}>
                    📦 {o.source}
                  </span>
                  {o.tracking ? (
                    <span style={{ color: "#1D4ED8", fontWeight: 600 }}>🚚 {o.tracking}</span>
                  ) : (
                    <button style={{ fontSize: 11, padding: "4px 10px", borderRadius: 8, border: "none", background: COLORS.dark, color: "white", cursor: "pointer", fontWeight: 600 }}>
                      Assign Courier
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "bookings" && (
        <div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {BOOKINGS.map(b => (
              <div key={b.id} style={{ background: COLORS.white, border: `1px solid ${b.flag ? COLORS.red : COLORS.border}`, borderRadius: 14, padding: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <div style={{ fontSize: 12, color: COLORS.muted, fontWeight: 700 }}>{b.id}</div>
                  <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 10, background: statusBg[b.status], color: statusColor[b.status] }}>
                    {b.status.charAt(0).toUpperCase() + b.status.slice(1)}
                  </span>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.dark }}>{b.customer}</div>
                <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>{b.service} · ₦{b.amount.toLocaleString()}</div>
                <div style={{ fontSize: 12, color: "#7C3AED", marginTop: 2, fontWeight: 500 }}>Provider: {b.provider}</div>
                {b.flag === "reassignment_pending" && (
                  <div style={{ marginTop: 10, background: COLORS.redBg, borderRadius: 8, padding: "8px 12px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: 12, color: COLORS.red, fontWeight: 600 }}>⚠ Awaiting manual reassignment</span>
                    <button style={{ fontSize: 11, padding: "5px 10px", borderRadius: 8, border: "none", background: COLORS.red, color: "white", cursor: "pointer", fontWeight: 700 }}>
                      Assign
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "providers" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {BARBERS.map(b => (
            <div key={b.id} style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, padding: 14, display: "flex", gap: 12, alignItems: "center" }}>
              <Avatar initials={b.avatar} color={b.color} size={44} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark }}>{b.name}</div>
                <div style={{ fontSize: 12, color: COLORS.muted }}>{b.location}</div>
                <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
                  <span style={{ fontSize: 11, color: COLORS.green, background: COLORS.greenBg, padding: "2px 7px", borderRadius: 8, fontWeight: 600 }}>KYC ✓</span>
                  <span style={{ fontSize: 11, color: "#1D4ED8", background: "#EFF6FF", padding: "2px 7px", borderRadius: 8 }}>{b.rating}★</span>
                  {b.mobile && <span style={{ fontSize: 11, color: "#7C3AED", background: "#F5F3FF", padding: "2px 7px", borderRadius: 8 }}>Mobile</span>}
                </div>
              </div>
              <button style={{ fontSize: 11, padding: "6px 10px", borderRadius: 8, border: `1px solid ${COLORS.border}`, background: COLORS.white, color: COLORS.muted, cursor: "pointer" }}>
                View
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProfileScreen({ setScreen, user, onLogout }) {
  const displayName = user?.name || "Emeka Okafor";
  const displayEmail = user?.contact || "emeka.okafor@gmail.com";
  const stats = [
    { label: "Total Cuts", value: "47" },
    { label: "TRIM Points", value: "340" },
    { label: "Saved", value: "₦8.4k" },
  ];

  return (
    <div style={{ padding: "0 16px", paddingBottom: 20 }}>
      <div style={{ paddingTop: 24, paddingBottom: 20, textAlign: "center" }}>
        <Avatar initials={displayName.split(" ").map(n => n[0]).join("").slice(0,2)} color={COLORS.accent} size={72} />
        <div style={{ fontSize: 20, fontWeight: 800, color: COLORS.dark, marginTop: 12 }}>{displayName}</div>
        <div style={{ fontSize: 13, color: COLORS.muted }}>{displayEmail}</div>
        <Badge>Founding Member</Badge>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 24 }}>
        {stats.map(s => (
          <div key={s.label} style={{ background: COLORS.surface, borderRadius: 10, padding: "12px 8px", textAlign: "center" }}>
            <div style={{ fontWeight: 800, fontSize: 18, color: COLORS.dark }}>{s.value}</div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 1, background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 16, overflow: "hidden" }}>
        {[
          { icon: "💳", label: "TRIM Wallet & Payments", sub: "Balance: ₦12,500" },
          { icon: "⭐", label: "My Barbers", sub: "3 saved barbers" },
          { icon: "📣", label: "Refer Your Barber", sub: "Earn 2 free cuts", highlight: true },
          { icon: "🎓", label: "TRIM Academy", sub: "0 courses enrolled" },
          { icon: "📋", label: "Subscription Plans", sub: "No active plan" },
          { icon: "⚙️", label: "Settings", sub: "" },
        ].map((item, i) => (
          <div key={item.label} style={{
            display: "flex", alignItems: "center", gap: 12, padding: "14px 16px",
            borderTop: i > 0 ? `1px solid ${COLORS.border}` : "none",
            cursor: "pointer", background: item.highlight ? COLORS.accentLight : COLORS.white,
          }}>
            <span style={{ fontSize: 20 }}>{item.icon}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: item.highlight ? COLORS.accentDark : COLORS.dark }}>{item.label}</div>
              {item.sub && <div style={{ fontSize: 12, color: COLORS.muted }}>{item.sub}</div>}
            </div>
            <span style={{ color: COLORS.muted, fontSize: 16 }}>›</span>
          </div>
        ))}
      </div>

      <button onClick={onLogout} style={{
        width: "100%", padding: 14, borderRadius: 14, marginTop: 16,
        border: `1px solid ${COLORS.border}`, background: COLORS.white,
        color: COLORS.red, fontSize: 14, fontWeight: 600, cursor: "pointer",
      }}>
        Log Out
      </button>
    </div>
  );
}

function TransportCalcScreen({ setScreen }) {
  const [distance, setDistance] = useState(12);
  const [trafficKey, setTrafficKey] = useState("moderate");
  const [servicePrice, setServicePrice] = useState(4000);
  const [outOfZone, setOutOfZone] = useState(false);

  const transportFee = calcTransportFee(distance, trafficKey, outOfZone);
  const bookingFee = Math.round(servicePrice * 0.12);
  const tc = TRAFFIC_MULTIPLIERS[trafficKey];
  const raw = Math.round(distance * BASE_RATE * tc.value);
  const providerCut = Math.round(transportFee * 0.8);
  const trimCut = transportFee - providerCut;
  const isCapped = raw > (outOfZone ? MAX_FEE_OUT_OF_ZONE : MAX_FEE);
  const isFloored = raw < MIN_FEE;

  return (
    <div style={{ padding: "0 16px", paddingBottom: 32 }}>
      <div style={{ paddingTop: 20, paddingBottom: 14, display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={() => setScreen("home")} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", padding: 0 }}>←</button>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.dark }}>Transport Fee Calculator</div>
          <div style={{ fontSize: 12, color: COLORS.muted }}>§5.6 Distance-Based Pricing Architecture</div>
        </div>
      </div>

      <div style={{ background: "#F0F9FF", borderRadius: 12, padding: "12px 14px", marginBottom: 16, border: "1px solid #BAE6FD" }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "#0369A1", marginBottom: 4 }}>Formula (§5.6.2)</div>
        <div style={{ fontFamily: "monospace", fontSize: 12, color: "#0C4A6E", lineHeight: 1.8 }}>
          Transport Fee = max(₦{MIN_FEE}, min(<br />
          &nbsp;&nbsp;distance × ₦{BASE_RATE}/km × multiplier,<br />
          &nbsp;&nbsp;₦{outOfZone ? MAX_FEE_OUT_OF_ZONE.toLocaleString() : MAX_FEE.toLocaleString()}{outOfZone ? " (out-of-zone)" : ""}<br />
          ))
        </div>
      </div>

      <div style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, padding: 16, marginBottom: 16 }}>
        <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark }}>Distance</label>
            <span style={{ fontSize: 14, fontWeight: 800, color: COLORS.dark }}>{distance} km</span>
          </div>
          <input type="range" min={1} max={42} step={1} value={distance}
            onChange={e => setDistance(Number(e.target.value))}
            style={{ width: "100%" }} />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: COLORS.muted, marginTop: 2 }}>
            <span>1km (min)</span>
            <span style={{ color: "#B45309", fontWeight: 600 }}>35km (zone limit)</span>
            <span style={{ color: COLORS.red }}>42km+ (events)</span>
          </div>
        </div>

        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 8 }}>Traffic Conditions</label>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 6 }}>
            {Object.entries(TRAFFIC_MULTIPLIERS).map(([key, tc]) => (
              <button key={key} onClick={() => setTrafficKey(key)} style={{
                padding: "8px 4px", borderRadius: 8,
                border: `2px solid ${trafficKey === key ? tc.color : COLORS.border}`,
                background: trafficKey === key ? tc.bg : COLORS.white,
                cursor: "pointer",
              }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: trafficKey === key ? tc.color : COLORS.muted }}>{tc.label}</div>
                <div style={{ fontSize: 10, color: trafficKey === key ? tc.color : COLORS.muted }}>{tc.badge}</div>
              </button>
            ))}
          </div>
          <div style={{ marginTop: 6, fontSize: 11, color: COLORS.muted }}>
            Peak hours 7–9am &amp; 4–8pm typically Heavy or Gridlock across Lagos
          </div>
        </div>

        <div style={{ marginBottom: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark }}>Service Price (for booking fee)</label>
            <span style={{ fontSize: 13, fontWeight: 700, color: COLORS.dark }}>₦{servicePrice.toLocaleString()}</span>
          </div>
          <input type="range" min={1500} max={15000} step={500} value={servicePrice}
            onChange={e => setServicePrice(Number(e.target.value))}
            style={{ width: "100%" }} />
        </div>

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark }}>Out-of-zone request</div>
            <div style={{ fontSize: 11, color: COLORS.muted }}>Standard cap lifted · Max ₦6,500</div>
          </div>
          <div
            onClick={() => setOutOfZone(v => !v)}
            style={{
              width: 44, height: 24, borderRadius: 12, cursor: "pointer",
              background: outOfZone ? "#3B82F6" : COLORS.border,
              position: "relative", transition: "background 0.2s",
            }}>
            <div style={{
              width: 18, height: 18, borderRadius: "50%", background: "white",
              position: "absolute", top: 3,
              left: outOfZone ? 23 : 3, transition: "left 0.2s",
              boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
            }} />
          </div>
        </div>
      </div>

      <div style={{ background: COLORS.white, border: `2px solid ${isFloored || isCapped ? "#3B82F6" : COLORS.border}`, borderRadius: 14, overflow: "hidden", marginBottom: 16 }}>
        <div style={{ padding: "14px 16px", borderBottom: `1px solid ${COLORS.border}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <div style={{ fontSize: 13, color: COLORS.muted }}>Raw calculation</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.dark }}>
              {distance} × ₦{BASE_RATE} × {tc.value} = ₦{raw.toLocaleString()}
            </div>
          </div>
          {isFloored && (
            <div style={{ fontSize: 12, color: "#1D4ED8", background: "#EFF6FF", borderRadius: 8, padding: "5px 10px" }}>
              ↑ Floored to minimum ₦{MIN_FEE} — short trips still cost the provider time
            </div>
          )}
          {isCapped && (
            <div style={{ fontSize: 12, color: "#DC2626", background: "#FEE2E2", borderRadius: 8, padding: "5px 10px" }}>
              ↓ Capped at ₦{(outOfZone ? MAX_FEE_OUT_OF_ZONE : MAX_FEE).toLocaleString()} — protects customers from extreme Lagos traffic
            </div>
          )}
        </div>

        <div style={{ padding: "14px 16px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 14 }}>
            <div style={{ fontSize: 13, color: COLORS.muted }}>Transport Fee</div>
            <div style={{ fontSize: 28, fontWeight: 900, color: "#1D4ED8" }}>₦{transportFee.toLocaleString()}</div>
          </div>

          <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
            <div style={{ flex: 4, background: "#DBEAFE", borderRadius: 10, padding: "10px 12px" }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#1E40AF" }}>₦{providerCut.toLocaleString()}</div>
              <div style={{ fontSize: 11, color: "#3B82F6", marginTop: 2 }}>80% → Provider (T+1 settlement)</div>
              <div style={{ fontSize: 10, color: "#60A5FA", marginTop: 2 }}>Fuel, Bolt/okada, vehicle cost</div>
            </div>
            <div style={{ flex: 1, background: "#F0F9FF", borderRadius: 10, padding: "10px 8px", textAlign: "center" }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#1E40AF" }}>₦{trimCut.toLocaleString()}</div>
              <div style={{ fontSize: 10, color: "#3B82F6", marginTop: 2 }}>20%<br />TRIM</div>
            </div>
          </div>

          <div style={{ borderTop: `1px solid ${COLORS.border}`, paddingTop: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.dark, marginBottom: 8 }}>Full booking total</div>
            {[
              { label: "Service price", value: `₦${servicePrice.toLocaleString()}` },
              { label: `Booking fee (12%)`, value: `₦${bookingFee.toLocaleString()}` },
              { label: `Transport fee`, value: `₦${transportFee.toLocaleString()}`, blue: true },
            ].map(r => (
              <div key={r.label} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 5 }}>
                <span style={{ color: COLORS.muted }}>{r.label}</span>
                <span style={{ fontWeight: 700, color: r.blue ? "#1D4ED8" : COLORS.dark }}>{r.value}</span>
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 15, fontWeight: 800, paddingTop: 8, borderTop: `1px solid ${COLORS.border}`, marginTop: 4 }}>
              <span style={{ color: COLORS.dark }}>Total (digital)</span>
              <span style={{ color: COLORS.dark }}>₦{(servicePrice + bookingFee + transportFee).toLocaleString()}</span>
            </div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 4 }}>
              OR: ₦{(bookingFee + transportFee).toLocaleString()} now + ₦{servicePrice.toLocaleString()} cash to barber
            </div>
          </div>
        </div>
      </div>

      <div style={{ background: COLORS.surface, borderRadius: 12, padding: 14, border: `1px solid ${COLORS.border}` }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.dark, marginBottom: 8 }}>Cancellation Policy (§5.6.5)</div>
        {[
          { when: "Before barber accepts", refund: "Full transport fee refunded" },
          { when: "After accept, before departure", refund: "Full transport fee refunded" },
          { when: "After barber departs (en route)", refund: "Non-refundable · 80% still paid to barber" },
          { when: "Barber cancels", refund: "Full refund · Barber incurs penalty" },
          { when: "Barber no-show", refund: "Full transport + service refunded in 24hrs" },
        ].map(r => (
          <div key={r.when} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `1px solid ${COLORS.border}`, fontSize: 12, gap: 12 }}>
            <span style={{ color: COLORS.muted, flex: 1 }}>{r.when}</span>
            <span style={{ fontWeight: 500, color: COLORS.dark, flex: 1, textAlign: "right" }}>{r.refund}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── AUTH SCREENS ────────────────────────────────────────────────────────────

function SplashScreen({ onRole }) {
  return (
    <div style={{
      minHeight: "100vh", display: "flex", flexDirection: "column",
      background: COLORS.dark, padding: "0 24px",
    }}>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", paddingTop: 60 }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>✂</div>
        <div style={{ fontSize: 42, fontWeight: 900, color: "white", letterSpacing: "-2px", marginBottom: 6 }}>TRIM</div>
        <div style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 8 }}>Lagos</div>
        <div style={{ fontSize: 15, color: "rgba(255,255,255,0.6)", textAlign: "center", lineHeight: 1.6, maxWidth: 260 }}>
          Book trusted barbers. Grow your grooming business.
        </div>
      </div>

      <div style={{ paddingBottom: 56 }}>
        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", textAlign: "center", marginBottom: 18, letterSpacing: "0.06em", textTransform: "uppercase" }}>
          I am joining as a…
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <button onClick={() => onRole("customer")} style={{
            padding: "18px 20px", borderRadius: 16, border: "none", cursor: "pointer",
            background: COLORS.accent, color: "white",
            display: "flex", alignItems: "center", gap: 14,
          }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>👤</div>
            <div style={{ textAlign: "left" }}>
              <div style={{ fontWeight: 800, fontSize: 16 }}>Customer</div>
              <div style={{ fontSize: 12, opacity: 0.85, marginTop: 1 }}>Book barbers, track appointments, shop</div>
            </div>
            <span style={{ marginLeft: "auto", fontSize: 18, opacity: 0.8 }}>›</span>
          </button>

          <button onClick={() => onRole("provider")} style={{
            padding: "18px 20px", borderRadius: 16, cursor: "pointer",
            background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)", color: "white",
            display: "flex", alignItems: "center", gap: 14,
          }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(255,255,255,0.12)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>💈</div>
            <div style={{ textAlign: "left" }}>
              <div style={{ fontWeight: 800, fontSize: 16 }}>Provider</div>
              <div style={{ fontSize: 12, opacity: 0.7, marginTop: 1 }}>Barber, stylist or salon owner</div>
            </div>
            <span style={{ marginLeft: "auto", fontSize: 18, opacity: 0.5 }}>›</span>
          </button>
        </div>

        <div style={{ textAlign: "center", fontSize: 12, color: "rgba(255,255,255,0.3)", marginTop: 20 }}>
          By continuing you agree to TRIM's Terms & Privacy Policy
        </div>
      </div>
    </div>
  );
}

function AuthScreen({ role, onAuth, onBack }) {
  const [mode, setMode] = useState("login"); // login | signup
  const [method, setMethod] = useState("phone"); // phone | email
  const [contact, setContact] = useState("");
  const [name, setName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [step, setStep] = useState("contact"); // contact | otp
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [error, setError] = useState("");

  const isProvider = role === "provider";
  const accentColor = isProvider ? "#7C3AED" : COLORS.accent;
  const accentLight = isProvider ? "#F5F3FF" : COLORS.accentLight;

  useEffect(() => {
    if (resendTimer > 0) {
      const t = setTimeout(() => setResendTimer(v => v - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [resendTimer]);

  const sendOtp = () => {
    if (!contact || contact.length < 6) { setError("Please enter a valid " + (method === "phone" ? "phone number" : "email")); return; }
    if (mode === "signup" && !name) { setError("Please enter your name"); return; }
    setError("");
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setStep("otp");
      setResendTimer(30);
    }, 1200);
  };

  const handleOtpChange = (val, idx) => {
    if (!/^\d*$/.test(val)) return;
    const next = [...otp];
    next[idx] = val.slice(-1);
    setOtp(next);
    if (val && idx < 5) {
      document.getElementById(`otp-${idx + 1}`)?.focus();
    }
  };

  const handleOtpKey = (e, idx) => {
    if (e.key === "Backspace" && !otp[idx] && idx > 0) {
      document.getElementById(`otp-${idx - 1}`)?.focus();
    }
  };

  const verifyOtp = () => {
    const code = otp.join("");
    if (code.length < 6) { setError("Enter all 6 digits"); return; }
    setError("");
    setVerifying(true);
    setTimeout(() => {
      setVerifying(false);
      // Demo: any 6-digit code works
      onAuth({
        role,
        name: name || (isProvider ? "Biodun Cuts" : "Emeka Okafor"),
        contact,
        method,
        businessName: isProvider ? (businessName || "My Barbershop") : null,
      });
    }, 1400);
  };

  const maskedContact = method === "phone"
    ? contact.slice(0, 4) + "****" + contact.slice(-3)
    : contact.split("@")[0].slice(0, 2) + "****@" + (contact.split("@")[1] || "");

  return (
    <div style={{
      minHeight: "100vh", background: COLORS.surface,
      fontFamily: "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
    }}>
      {/* Header */}
      <div style={{
        background: COLORS.dark, padding: "52px 20px 28px",
        position: "relative",
      }}>
        <button onClick={onBack} style={{ position: "absolute", top: 16, left: 16, background: "rgba(255,255,255,0.1)", border: "none", color: "white", borderRadius: 10, padding: "6px 12px", fontSize: 13, cursor: "pointer" }}>
          ← Back
        </button>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 48, height: 48, borderRadius: 14, background: isProvider ? "#7C3AED" : COLORS.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>
            {isProvider ? "💈" : "👤"}
          </div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 800, color: "white" }}>
              {mode === "login" ? "Welcome back" : isProvider ? "Join as Provider" : "Create Account"}
            </div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", marginTop: 2 }}>
              {isProvider ? "Barber / Salon / Stylist" : "Customer"}
            </div>
          </div>
        </div>

        {/* Login / Sign up toggle */}
        <div style={{ display: "flex", gap: 0, marginTop: 20, background: "rgba(255,255,255,0.08)", borderRadius: 10, padding: 3 }}>
          {["login", "signup"].map(m => (
            <button key={m} onClick={() => { setMode(m); setStep("contact"); setOtp(["","","","","",""]); setError(""); }} style={{
              flex: 1, padding: "9px", borderRadius: 8, border: "none", cursor: "pointer",
              background: mode === m ? "white" : "transparent",
              color: mode === m ? COLORS.dark : "rgba(255,255,255,0.5)",
              fontWeight: 700, fontSize: 13, transition: "all 0.2s",
            }}>
              {m === "login" ? "Log In" : "Sign Up"}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "24px 20px" }}>
        {step === "contact" && (
          <>
            {/* Method picker */}
            <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
              {["phone", "email"].map(m => (
                <button key={m} onClick={() => { setMethod(m); setContact(""); setError(""); }} style={{
                  flex: 1, padding: "10px", borderRadius: 10,
                  border: `2px solid ${method === m ? accentColor : COLORS.border}`,
                  background: method === m ? accentLight : COLORS.white,
                  color: method === m ? accentColor : COLORS.muted,
                  fontWeight: 600, fontSize: 13, cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                }}>
                  <span>{m === "phone" ? "📱" : "📧"}</span>
                  {m === "phone" ? "Phone Number" : "Email"}
                </button>
              ))}
            </div>

            {/* Name fields for signup */}
            {mode === "signup" && (
              <>
                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 6 }}>
                    {isProvider ? "Your Full Name" : "Full Name"}
                  </label>
                  <input
                    value={name} onChange={e => setName(e.target.value)}
                    placeholder={isProvider ? "e.g. Biodun Adeleke" : "e.g. Emeka Okafor"}
                    style={{ width: "100%", padding: "13px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, boxSizing: "border-box", outline: "none" }}
                  />
                </div>
                {isProvider && (
                  <div style={{ marginBottom: 14 }}>
                    <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 6 }}>Business / Shop Name</label>
                    <input
                      value={businessName} onChange={e => setBusinessName(e.target.value)}
                      placeholder="e.g. Biodun Cuts Ikeja"
                      style={{ width: "100%", padding: "13px 14px", borderRadius: 12, border: `1.5px solid ${COLORS.border}`, fontSize: 14, boxSizing: "border-box", outline: "none" }}
                    />
                  </div>
                )}
              </>
            )}

            {/* Contact input */}
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 6 }}>
                {method === "phone" ? "Phone Number" : "Email Address"}
              </label>
              <div style={{ position: "relative" }}>
                {method === "phone" && (
                  <div style={{
                    position: "absolute", left: 0, top: 0, bottom: 0,
                    width: 60, display: "flex", alignItems: "center", justifyContent: "center",
                    borderRight: `1px solid ${COLORS.border}`,
                    fontSize: 13, fontWeight: 600, color: COLORS.dark,
                    background: COLORS.surface, borderRadius: "12px 0 0 12px",
                  }}>
                    🇳🇬 +234
                  </div>
                )}
                <input
                  value={contact}
                  onChange={e => setContact(e.target.value)}
                  type={method === "email" ? "email" : "tel"}
                  placeholder={method === "phone" ? "0801 234 5678" : "you@example.com"}
                  style={{
                    width: "100%", padding: method === "phone" ? "13px 14px 13px 72px" : "13px 14px",
                    borderRadius: 12, border: `1.5px solid ${error ? COLORS.red : COLORS.border}`,
                    fontSize: 14, boxSizing: "border-box", outline: "none",
                  }}
                />
              </div>
              {error && <div style={{ fontSize: 12, color: COLORS.red, marginTop: 5 }}>⚠ {error}</div>}
            </div>

            <button onClick={sendOtp} disabled={sending} style={{
              width: "100%", padding: 16, borderRadius: 14, border: "none",
              background: sending ? COLORS.border : accentColor, color: "white",
              fontSize: 15, fontWeight: 700, cursor: sending ? "not-allowed" : "pointer",
            }}>
              {sending ? "Sending OTP…" : `Send OTP via ${method === "phone" ? "SMS" : "Email"}`}
            </button>

            {isProvider && mode === "signup" && (
              <div style={{ marginTop: 16, background: "#F5F3FF", borderRadius: 12, padding: "12px 14px", fontSize: 12, color: "#6D28D9", lineHeight: 1.6 }}>
                <strong>Provider accounts</strong> require KYC verification (BVN / NIN + liveness check via Smile Identity) before your profile goes live. You can complete this after sign-up.
              </div>
            )}
          </>
        )}

        {step === "otp" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{ fontSize: 48, marginBottom: 10 }}>{method === "phone" ? "📱" : "📧"}</div>
              <div style={{ fontSize: 17, fontWeight: 700, color: COLORS.dark, marginBottom: 6 }}>Enter verification code</div>
              <div style={{ fontSize: 13, color: COLORS.muted, lineHeight: 1.6 }}>
                We sent a 6-digit OTP to<br />
                <strong style={{ color: COLORS.dark }}>{maskedContact}</strong>
              </div>
            </div>

            {/* 6-digit OTP boxes */}
            <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 8 }}>
              {otp.map((digit, idx) => (
                <input
                  key={idx}
                  id={`otp-${idx}`}
                  value={digit}
                  onChange={e => handleOtpChange(e.target.value, idx)}
                  onKeyDown={e => handleOtpKey(e, idx)}
                  maxLength={1}
                  inputMode="numeric"
                  style={{
                    width: 44, height: 52, textAlign: "center", fontSize: 22, fontWeight: 700,
                    borderRadius: 12,
                    border: `2px solid ${digit ? accentColor : COLORS.border}`,
                    background: digit ? accentLight : COLORS.white,
                    color: COLORS.dark, outline: "none",
                  }}
                />
              ))}
            </div>

            {error && <div style={{ textAlign: "center", fontSize: 12, color: COLORS.red, marginBottom: 8 }}>⚠ {error}</div>}

            <div style={{ textAlign: "center", fontSize: 12, color: COLORS.muted, marginBottom: 20 }}>
              {resendTimer > 0
                ? `Resend OTP in ${resendTimer}s`
                : <span onClick={() => { setOtp(["","","","","",""]); sendOtp(); }} style={{ color: accentColor, fontWeight: 600, cursor: "pointer" }}>Resend OTP</span>
              }
            </div>

            <button onClick={verifyOtp} disabled={verifying || otp.join("").length < 6} style={{
              width: "100%", padding: 16, borderRadius: 14, border: "none",
              background: verifying || otp.join("").length < 6 ? COLORS.border : accentColor,
              color: verifying || otp.join("").length < 6 ? COLORS.muted : "white",
              fontSize: 15, fontWeight: 700, cursor: verifying ? "not-allowed" : "pointer",
            }}>
              {verifying ? "Verifying…" : "Verify & Continue"}
            </button>

            <button onClick={() => { setStep("contact"); setOtp(["","","","","",""]); setError(""); }} style={{
              width: "100%", marginTop: 10, padding: 12, borderRadius: 14,
              border: `1px solid ${COLORS.border}`, background: COLORS.white,
              color: COLORS.muted, fontSize: 14, cursor: "pointer",
            }}>
              ← Change {method === "phone" ? "number" : "email"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ─── SHARED DEMO DATA ────────────────────────────────────────────────────────

const DEMO_CUSTOMERS = [
  { id: "c1", name: "Tunde Adeyemi",  phone: "+2348031234567", avatar: "TA", color: "#F59E0B", bookings: 7,  spent: "₦24,500", lastService: "Fade + Beard",   date: "Today 9:00 AM",    status: "confirmed", amount: 3500, blocked: true  },
  { id: "c2", name: "Femi Okonkwo",   phone: "+2348056789012", avatar: "FO", color: "#10B981", bookings: 3,  spent: "₦7,500",  lastService: "Classic Cut",    date: "Today 11:00 AM",   status: "confirmed", amount: 2500, blocked: true  },
  { id: "c3", name: "David Kingsley", phone: "+2349071234560", avatar: "DK", color: "#6366F1", bookings: 1,  spent: "₦4,500",  lastService: "Full Package",   date: "Today 2:00 PM",    status: "pending",   amount: 4500, blocked: false },
  { id: "c4", name: "Chukwu Emeka",   phone: "+2348099887766", avatar: "CE", color: "#EC4899", bookings: 12, spent: "₦43,000", lastService: "Full Package",   date: "Sat May 20 10:00", status: "confirmed", amount: 4500, blocked: true  },
];

// ─── CUSTOMER PROFILE MODAL (Provider sees this) ──────────────────────────────
function CustomerProfileModal({ customer, onClose }) {
  const [chatOpen, setChatOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([
    { from: "customer", text: "Hi, I'll be there at 9 sharp!", time: "8:42 AM" },
    { from: "provider", text: "Great, I'll have your slot ready 👍", time: "8:45 AM" },
  ]);

  const sendMessage = () => {
    if (!message.trim()) return;
    setMessages(prev => [...prev, { from: "provider", text: message, time: "now" }]);
    setMessage("");
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 300, display: "flex", alignItems: "flex-end" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 420, maxHeight: "90vh", display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", justifyContent: "center", padding: "12px 0 4px" }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: COLORS.border }} />
        </div>

        {!chatOpen ? (
          <div style={{ padding: "4px 20px 36px", overflowY: "auto" }}>
            {/* Customer header */}
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20, paddingBottom: 20, borderBottom: `1px solid ${COLORS.border}` }}>
              <div style={{ width: 64, height: 64, borderRadius: "50%", background: customer.color + "22", border: `2px solid ${customer.color}55`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 800, color: customer.color, flexShrink: 0 }}>
                {customer.avatar}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.dark }}>{customer.name}</div>
                <div style={{ fontSize: 13, color: COLORS.muted, marginTop: 2 }}>{customer.phone}</div>
                <div style={{ fontSize: 12, color: COLORS.green, marginTop: 2, fontWeight: 500 }}>
                  {customer.bookings} bookings · {customer.spent} spent
                </div>
              </div>
            </div>

            {/* Booking info */}
            <div style={{ background: COLORS.surface, borderRadius: 12, padding: 14, marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.dark, marginBottom: 8 }}>Current Booking</div>
              {[
                { label: "Service", value: customer.lastService },
                { label: "Appointment", value: customer.date },
                { label: "Amount", value: `₦${customer.amount.toLocaleString()}` },
                { label: "Status", value: customer.status === "confirmed" ? "✓ Confirmed & Paid" : "⏳ Pending Payment" },
              ].map(r => (
                <div key={r.label} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                  <span style={{ color: COLORS.muted }}>{r.label}</span>
                  <span style={{ fontWeight: 600, color: r.label === "Status" ? (customer.status === "confirmed" ? COLORS.green : COLORS.accent) : COLORS.dark }}>{r.value}</span>
                </div>
              ))}
            </div>

            {/* Calendar auto-block notice */}
            {customer.blocked && (
              <div style={{ background: "#F5F3FF", borderRadius: 10, padding: "10px 14px", marginBottom: 16, display: "flex", gap: 8, alignItems: "center", border: "1px solid #DDD6FE" }}>
                <span style={{ fontSize: 18 }}>🔒</span>
                <div style={{ fontSize: 12, color: "#6D28D9", lineHeight: 1.5 }}>
                  <strong>Auto-blocked:</strong> This time slot was automatically locked on your calendar the moment payment was confirmed.
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
              <button onClick={() => setChatOpen(true)} style={{ padding: "13px 0", borderRadius: 14, background: "#7C3AED", color: "white", border: "none", fontWeight: 700, fontSize: 14, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                💬 Message
              </button>
              <a href={`tel:${customer.phone}`} style={{ textDecoration: "none" }}>
                <button style={{ width: "100%", padding: "13px 0", borderRadius: 14, background: COLORS.green, color: "white", border: "none", fontWeight: 700, fontSize: 14, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                  📞 Call
                </button>
              </a>
            </div>

            {/* Decline booking */}
            {customer.status === "pending" && (
              <button onClick={onClose} style={{ width: "100%", padding: 12, borderRadius: 14, border: `1px solid ${COLORS.red}`, background: COLORS.white, color: COLORS.red, fontWeight: 600, fontSize: 14, cursor: "pointer" }}>
                ✗ Decline This Booking
              </button>
            )}
          </div>
        ) : (
          /* In-app chat */
          <div style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0 }}>
            <div style={{ padding: "8px 16px 12px", borderBottom: `1px solid ${COLORS.border}`, display: "flex", alignItems: "center", gap: 10 }}>
              <button onClick={() => setChatOpen(false)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", padding: 0 }}>←</button>
              <div style={{ width: 36, height: 36, borderRadius: "50%", background: customer.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 800, color: customer.color }}>
                {customer.avatar}
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.dark }}>{customer.name}</div>
                <div style={{ fontSize: 11, color: COLORS.green }}>● Active now</div>
              </div>
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
              {messages.map((msg, i) => (
                <div key={i} style={{ display: "flex", justifyContent: msg.from === "provider" ? "flex-end" : "flex-start" }}>
                  <div style={{
                    maxWidth: "75%", padding: "10px 14px", borderRadius: msg.from === "provider" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                    background: msg.from === "provider" ? "#7C3AED" : COLORS.surface,
                    color: msg.from === "provider" ? "white" : COLORS.dark,
                    fontSize: 13, lineHeight: 1.5,
                  }}>
                    {msg.text}
                    <div style={{ fontSize: 10, opacity: 0.6, marginTop: 4, textAlign: "right" }}>{msg.time}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ padding: "12px 16px 28px", borderTop: `1px solid ${COLORS.border}`, display: "flex", gap: 8 }}>
              <input value={message} onChange={e => setMessage(e.target.value)} onKeyDown={e => e.key === "Enter" && sendMessage()}
                placeholder="Type a message…"
                style={{ flex: 1, padding: "11px 14px", borderRadius: 24, border: `1px solid ${COLORS.border}`, fontSize: 14, outline: "none" }} />
              <button onClick={sendMessage} style={{ width: 44, height: 44, borderRadius: "50%", background: "#7C3AED", border: "none", color: "white", fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                ↑
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── BOOKING DECLINE + REASSIGNMENT MODAL ─────────────────────────────────────
function DeclineReassignModal({ booking, onClose }) {
  const [step, setStep] = useState("decline"); // decline | reassign | customer_choice | done
  const [mode, setMode] = useState(null); // manual | auto
  const [assigned, setAssigned] = useState(null);
  const [customerChoice, setCustomerChoice] = useState(null);

  const alternates = [
    { name: "Emeka Razors", rating: 5.0, distance: "1.2km", slot: booking?.date, available: true, avatar: "ER", color: "#7C3AED" },
    { name: "Seun Fades",   rating: 4.7, distance: "2.4km", slot: booking?.date, available: true, avatar: "SF", color: "#F59E0B" },
  ];

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 300, display: "flex", alignItems: "flex-end" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 420, padding: "16px 20px 40px" }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 12 }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: COLORS.border }} />
        </div>

        {step === "decline" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ fontSize: 40, marginBottom: 8 }}>⚠️</div>
              <div style={{ fontSize: 17, fontWeight: 800, color: COLORS.dark }}>Decline Booking?</div>
              <div style={{ fontSize: 13, color: COLORS.muted, marginTop: 6, lineHeight: 1.6 }}>
                Before any refund is issued, TRIM will attempt to reassign <strong>{booking?.client}</strong> to an available provider.
              </div>
            </div>
            <div style={{ background: COLORS.accentLight, borderRadius: 12, padding: 14, marginBottom: 20, fontSize: 12, color: COLORS.accentDark, lineHeight: 1.6 }}>
              <strong>Reassignment Protocol:</strong> The customer will be offered a matched provider or the option to wait for your next available slot. A refund is only processed if they opt out of both.
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <button onClick={onClose} style={{ padding: 13, borderRadius: 12, border: `1px solid ${COLORS.border}`, background: COLORS.white, color: COLORS.muted, fontWeight: 600, fontSize: 14, cursor: "pointer" }}>
                Keep Booking
              </button>
              <button onClick={() => setStep("reassign")} style={{ padding: 13, borderRadius: 12, border: "none", background: COLORS.red, color: "white", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
                Decline →
              </button>
            </div>
          </>
        )}

        {step === "reassign" && (
          <>
            <div style={{ fontSize: 17, fontWeight: 800, color: COLORS.dark, marginBottom: 4 }}>Reassignment Options</div>
            <div style={{ fontSize: 13, color: COLORS.muted, marginBottom: 16 }}>Choose how to reassign {booking?.client}'s booking</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
              {[
                { id: "auto", icon: "⚡", label: "Auto-assign", sub: "System picks the highest-rated available provider in the area", color: "#F5F3FF", border: "#DDD6FE" },
                { id: "manual", icon: "👨‍💼", label: "Admin manual assign", sub: "Flag to admin for manual provider selection", color: "#FFF7ED", border: "#FED7AA" },
              ].map(opt => (
                <div key={opt.id} onClick={() => setMode(opt.id)} style={{
                  padding: 14, borderRadius: 14, cursor: "pointer",
                  border: `2px solid ${mode === opt.id ? "#7C3AED" : opt.border}`,
                  background: mode === opt.id ? "#F5F3FF" : opt.color,
                }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <span style={{ fontSize: 24 }}>{opt.icon}</span>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark }}>{opt.label}</div>
                      <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>{opt.sub}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {mode === "auto" && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.dark, marginBottom: 8 }}>Suggested Match</div>
                {alternates.map(a => (
                  <div key={a.name} onClick={() => setAssigned(a)} style={{
                    display: "flex", alignItems: "center", gap: 10, padding: 12, borderRadius: 12,
                    border: `2px solid ${assigned?.name === a.name ? "#7C3AED" : COLORS.border}`,
                    background: assigned?.name === a.name ? "#F5F3FF" : COLORS.white, cursor: "pointer", marginBottom: 6,
                  }}>
                    <div style={{ width: 40, height: 40, borderRadius: "50%", background: a.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, color: a.color }}>
                      {a.avatar}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.dark }}>{a.name}</div>
                      <div style={{ fontSize: 11, color: COLORS.muted }}>{a.rating}★ · {a.distance} · {a.slot}</div>
                    </div>
                    {assigned?.name === a.name && <span style={{ color: "#7C3AED", fontSize: 18 }}>✓</span>}
                  </div>
                ))}
              </div>
            )}
            <button onClick={() => mode && setStep("customer_choice")} disabled={!mode} style={{
              width: "100%", padding: 14, borderRadius: 14, border: "none",
              background: mode ? "#7C3AED" : COLORS.border,
              color: mode ? "white" : COLORS.muted,
              fontWeight: 700, fontSize: 14, cursor: mode ? "pointer" : "not-allowed",
            }}>
              {mode === "manual" ? "Flag for Admin →" : "Notify Customer →"}
            </button>
          </>
        )}

        {step === "customer_choice" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 36, marginBottom: 8 }}>📲</div>
              <div style={{ fontSize: 16, fontWeight: 800, color: COLORS.dark }}>Customer Notified</div>
              <div style={{ fontSize: 13, color: COLORS.muted, marginTop: 4, lineHeight: 1.6 }}>
                {booking?.client} was sent a notification. They must choose one of the following options.
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
              {[
                { id: "accept", icon: "✓", label: `Accept ${assigned?.name || "reassigned provider"}`, sub: "Same slot · Same service · No fee change", color: COLORS.greenBg, border: COLORS.green, textColor: COLORS.green },
                { id: "wait",   icon: "⏳", label: "Wait for original provider", sub: "Held slot — rebooked for next available time", color: "#FFF7ED", border: COLORS.accent, textColor: COLORS.accentDark },
                { id: "refund", icon: "↩", label: "Decline both — request refund", sub: "Full refund processed in 24–48hrs", color: COLORS.redBg, border: COLORS.red, textColor: COLORS.red },
              ].map(c => (
                <div key={c.id} onClick={() => setCustomerChoice(c.id)} style={{
                  padding: 14, borderRadius: 14, cursor: "pointer",
                  border: `2px solid ${customerChoice === c.id ? c.border : COLORS.border}`,
                  background: customerChoice === c.id ? c.color : COLORS.white,
                }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: customerChoice === c.id ? c.textColor : COLORS.dark }}>{c.icon} {c.label}</div>
                  <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>{c.sub}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 12, textAlign: "center" }}>
              Demo: select a choice above to simulate customer response
            </div>
            <button onClick={() => customerChoice && setStep("done")} disabled={!customerChoice} style={{
              width: "100%", padding: 14, borderRadius: 14, border: "none",
              background: customerChoice ? "#7C3AED" : COLORS.border,
              color: customerChoice ? "white" : COLORS.muted,
              fontWeight: 700, fontSize: 14, cursor: customerChoice ? "pointer" : "not-allowed",
            }}>
              Confirm Customer Response →
            </button>
          </>
        )}

        {step === "done" && (
          <div style={{ textAlign: "center", padding: "8px 0 12px" }}>
            <div style={{ fontSize: 56, marginBottom: 12 }}>{customerChoice === "accept" ? "✅" : customerChoice === "wait" ? "⏳" : "↩"}</div>
            <div style={{ fontSize: 17, fontWeight: 800, color: COLORS.dark, marginBottom: 6 }}>
              {customerChoice === "accept" ? "Reassignment Confirmed" : customerChoice === "wait" ? "Customer is Waiting" : "Refund Initiated"}
            </div>
            <div style={{ fontSize: 13, color: COLORS.muted, lineHeight: 1.6, marginBottom: 20 }}>
              {customerChoice === "accept" && `${booking?.client} has accepted ${assigned?.name || "the new provider"}. The booking has been transferred.`}
              {customerChoice === "wait" && `${booking?.client} chose to wait. Their slot will be held and re-offered when you're next available.`}
              {customerChoice === "refund" && `${booking?.client} opted out. A full refund of ₦${booking?.amount?.toLocaleString()} will be processed within 24hrs.`}
            </div>
            <button onClick={onClose} style={{ padding: "13px 32px", borderRadius: 14, border: "none", background: "#7C3AED", color: "white", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── PROVIDER HOME SCREEN ────────────────────────────────────────────────────
function ProviderHomeScreen({ user, setScreen }) {
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [declineBooking, setDeclineBooking] = useState(null);

  return (
    <div style={{ padding: "0 16px 16px" }}>
      <div style={{ paddingTop: 24, paddingBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ fontSize: 13, color: COLORS.muted }}>Good morning</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark, letterSpacing: "-0.5px" }}>{user.name} 💈</div>
          <div style={{ fontSize: 12, color: "#7C3AED", marginTop: 2, fontWeight: 500 }}>{user.businessName}</div>
        </div>
        <div style={{ background: COLORS.greenBg, color: COLORS.green, fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 20 }}>
          ● Available
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 20 }}>
        {[
          { label: "Today", value: DEMO_CUSTOMERS.filter(c => c.date.startsWith("Today")).length, sub: "bookings" },
          { label: "This week", value: "₦42k", sub: "earnings" },
          { label: "Rating", value: "4.9★", sub: "avg score" },
        ].map(s => (
          <div key={s.label} style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "12px 10px", textAlign: "center" }}>
            <div style={{ fontWeight: 800, fontSize: 18, color: COLORS.dark }}>{s.value}</div>
            <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 1 }}>{s.sub}</div>
            <div style={{ fontSize: 10, color: "#7C3AED", marginTop: 1 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Today's queue — tap customer to open profile */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.dark }}>Today's Queue</div>
          <button onClick={() => setScreen("providerCalendar")} style={{ background: "none", border: "none", color: "#7C3AED", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Week View →</button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {DEMO_CUSTOMERS.filter(c => c.date.startsWith("Today")).map(c => (
            <div key={c.id} style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 14, padding: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                {/* Time column */}
                <div style={{ width: 44, textAlign: "center", flexShrink: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.dark }}>{c.date.split(" ")[1]}</div>
                  <div style={{ fontSize: 10, color: COLORS.muted }}>{c.date.split(" ")[2]}</div>
                </div>
                {/* Info */}
                <div onClick={() => setSelectedCustomer(c)} style={{ flex: 1, borderLeft: `3px solid ${c.status === "pending" ? COLORS.accent : "#7C3AED"}`, paddingLeft: 12, cursor: "pointer" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: c.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: c.color }}>{c.avatar}</div>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 13, color: COLORS.dark }}>{c.name}</div>
                      <div style={{ fontSize: 11, color: COLORS.muted }}>{c.lastService}</div>
                    </div>
                  </div>
                </div>
                {/* Amount + status + actions */}
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.dark }}>₦{c.amount.toLocaleString()}</div>
                  <div style={{ fontSize: 10, marginTop: 2, color: c.status === "pending" ? COLORS.accent : COLORS.green, fontWeight: 500 }}>
                    {c.status === "pending" ? "Pending" : "Confirmed"}
                    {c.blocked && " 🔒"}
                  </div>
                  {c.status === "pending" && (
                    <button onClick={() => setDeclineBooking(c)} style={{ marginTop: 4, fontSize: 10, padding: "2px 7px", borderRadius: 6, border: `1px solid ${COLORS.red}`, background: COLORS.white, color: COLORS.red, cursor: "pointer", fontWeight: 600 }}>
                      Decline
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.dark, marginBottom: 12 }}>Quick Actions</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {[
          { icon: "🚫", label: "Block Time",    sub: "Mark unavailable",    color: "#FEE2E2", action: "providerCalendar" },
          { icon: "💸", label: "Withdraw",       sub: "₦38,400 available",   color: "#DCFCE7", action: "providerEarnings" },
          { icon: "📝", label: "Edit Services",  sub: "Update pricing",      color: "#F5F3FF", action: "providerServices" },
          { icon: "📊", label: "Analytics",      sub: "View insights",       color: "#FFF7ED", action: "providerEarnings" },
        ].map(item => (
          <div key={item.label} onClick={() => setScreen(item.action)} style={{ background: item.color, borderRadius: 14, padding: 14, cursor: "pointer", border: `1px solid ${COLORS.border}` }}>
            <div style={{ fontSize: 24, marginBottom: 6 }}>{item.icon}</div>
            <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark }}>{item.label}</div>
            <div style={{ fontSize: 11, color: COLORS.muted }}>{item.sub}</div>
          </div>
        ))}
      </div>

      {selectedCustomer && <CustomerProfileModal customer={selectedCustomer} onClose={() => setSelectedCustomer(null)} />}
      {declineBooking && <DeclineReassignModal booking={declineBooking} onClose={() => setDeclineBooking(null)} />}
    </div>
  );
}

function ProviderBottomNav({ screen, setScreen }) {
  const items = [
    { id: "providerHome", icon: "🏠", label: "Home" },
    { id: "providerCalendar", icon: "📅", label: "Schedule" },
    { id: "providerEarnings", icon: "💰", label: "Earnings" },
    { id: "providerServices", icon: "✂", label: "Services" },
    { id: "providerShop", icon: "🛍", label: "Shop" },
    { id: "providerProfile", icon: "👤", label: "Profile" },
  ];
  return (
    <div style={{
      position: "sticky", bottom: 0,
      background: COLORS.white, borderTop: `1px solid ${COLORS.border}`,
      display: "flex", justifyContent: "space-around",
      padding: "8px 0 12px", zIndex: 100,
    }}>
      {items.map(item => (
        <button key={item.id} onClick={() => setScreen(item.id)} style={{
          background: "none", border: "none", cursor: "pointer",
          display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
          padding: "4px 8px",
          opacity: screen === item.id ? 1 : 0.45,
        }}>
          <span style={{ fontSize: 20 }}>{item.icon}</span>
          <span style={{ fontSize: 10, fontWeight: screen === item.id ? 700 : 400, color: screen === item.id ? "#7C3AED" : COLORS.muted }}>
            {item.label}
          </span>
        </button>
      ))}
    </div>
  );
}

function ProviderCalendarScreen() {
  const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const HOURS = ["8am","9am","10am","11am","12pm","1pm","2pm","3pm","4pm","5pm","6pm"];
  const [viewMode, setViewMode] = useState("week"); // week | day
  const [selectedDay, setSelectedDay] = useState("Mon");
  const [availability, setAvailability] = useState({ Mon:true, Tue:true, Wed:true, Thu:true, Fri:true, Sat:true, Sun:false });

  // Auto-blocked by confirmed paid bookings
  const AUTO_BLOCKED = {
    Mon: { "9am": { client: "Tunde A.", type: "paid" }, "11am": { client: "Femi O.", type: "paid" }, "2pm": { client: "David K.", type: "pending" } },
    Tue: { "10am": { client: "Chukwu E.", type: "paid" }, "3pm": { client: "Rasheed B.", type: "paid" } },
    Wed: { "9am": { client: "Ibrahim Y.", type: "paid" } },
    Thu: {},
    Fri: { "11am": { client: "Gbenga A.", type: "paid" }, "1pm": { client: "Segun M.", type: "paid" }, "4pm": { client: "Biodun T.", type: "pending" } },
    Sat: { "9am": { client: "Wale D.", type: "paid" }, "10am": { client: "Emeka K.", type: "paid" }, "11am": { client: "Tayo P.", type: "paid" }, "2pm": { client: "Felix O.", type: "paid" } },
    Sun: {},
  };

  // Manual blocked by provider
  const [manualBlocked, setManualBlocked] = useState({ Mon: ["12pm"], Wed: ["3pm","4pm"], Fri: [] });
  const toggleManual = (day, hour) => {
    const booked = AUTO_BLOCKED[day]?.[hour];
    if (booked) return; // can't unblock a paid booking
    setManualBlocked(prev => {
      const curr = prev[day] || [];
      return { ...prev, [day]: curr.includes(hour) ? curr.filter(h => h !== hour) : [...curr, hour] };
    });
  };

  const getSlotState = (day, hour) => {
    const auto = AUTO_BLOCKED[day]?.[hour];
    if (auto) return auto.type === "paid" ? "paid" : "pending";
    if ((manualBlocked[day] || []).includes(hour)) return "manual";
    return "free";
  };

  const slotColor = { paid: "#7C3AED", pending: COLORS.accent, manual: COLORS.red, free: COLORS.border };
  const slotBg    = { paid: "#F5F3FF", pending: COLORS.accentLight, manual: "#FEE2E2", free: COLORS.white };
  const slotLabel = { paid: "Booked ✓", pending: "Pending", manual: "Blocked", free: "Free" };

  return (
    <div style={{ padding: "0 16px 24px" }}>
      <div style={{ paddingTop: 24, paddingBottom: 14 }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark }}>Schedule</div>
        <div style={{ fontSize: 13, color: COLORS.muted }}>Week of May 19–25, 2026</div>
      </div>

      {/* View toggle */}
      <div style={{ display: "flex", background: COLORS.surface, borderRadius: 10, padding: 3, marginBottom: 16, gap: 3 }}>
        {["week","day"].map(v => (
          <button key={v} onClick={() => setViewMode(v)} style={{
            flex: 1, padding: "8px", borderRadius: 8, border: "none",
            background: viewMode === v ? "white" : "transparent",
            color: viewMode === v ? COLORS.dark : COLORS.muted,
            fontWeight: 700, fontSize: 13, cursor: "pointer",
            boxShadow: viewMode === v ? "0 1px 4px rgba(0,0,0,0.08)" : "none",
          }}>
            {v === "week" ? "📅 Week" : "📋 Day"}
          </button>
        ))}
      </div>

      {/* Legend */}
      <div style={{ display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
        {[
          { color: "#7C3AED", bg: "#F5F3FF", label: "Auto-locked (paid booking)" },
          { color: COLORS.accent, bg: COLORS.accentLight, label: "Pending payment" },
          { color: COLORS.red,   bg: "#FEE2E2", label: "Manually blocked" },
          { color: COLORS.muted, bg: COLORS.white, label: "Available" },
        ].map(l => (
          <div key={l.label} style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <div style={{ width: 10, height: 10, borderRadius: 3, background: l.bg, border: `2px solid ${l.color}` }} />
            <span style={{ fontSize: 10, color: COLORS.muted }}>{l.label}</span>
          </div>
        ))}
      </div>

      {viewMode === "week" ? (
        /* ── WEEK VIEW ── compact grid */
        <div style={{ overflowX: "auto" }}>
          <div style={{ minWidth: 380 }}>
            {/* Day headers */}
            <div style={{ display: "grid", gridTemplateColumns: "44px repeat(7, 1fr)", gap: 3, marginBottom: 4 }}>
              <div />
              {DAYS.map(d => {
                const bookingCount = Object.keys(AUTO_BLOCKED[d] || {}).length;
                return (
                  <div key={d} onClick={() => { setSelectedDay(d); setViewMode("day"); }} style={{
                    textAlign: "center", padding: "6px 2px", borderRadius: 8, cursor: "pointer",
                    background: d === "Mon" ? "#F5F3FF" : COLORS.surface,
                    border: d === "Mon" ? "1.5px solid #7C3AED" : `1px solid ${COLORS.border}`,
                  }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: d === "Mon" ? "#7C3AED" : COLORS.muted }}>{d}</div>
                    {bookingCount > 0 && (
                      <div style={{ fontSize: 9, background: "#7C3AED", color: "white", borderRadius: 6, padding: "1px 4px", marginTop: 2 }}>
                        {bookingCount}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {/* Hour rows */}
            {HOURS.map(hour => (
              <div key={hour} style={{ display: "grid", gridTemplateColumns: "44px repeat(7, 1fr)", gap: 3, marginBottom: 3 }}>
                <div style={{ fontSize: 10, color: COLORS.muted, textAlign: "right", paddingRight: 6, paddingTop: 6 }}>{hour}</div>
                {DAYS.map(d => {
                  const state = getSlotState(d, hour);
                  const booking = AUTO_BLOCKED[d]?.[hour];
                  return (
                    <div key={d} onClick={() => { if (state === "free" || state === "manual") toggleManual(d, hour); }}
                      style={{
                        height: 32, borderRadius: 6, cursor: state === "paid" || state === "pending" ? "default" : "pointer",
                        background: slotBg[state], border: `1.5px solid ${slotColor[state]}`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        overflow: "hidden",
                      }}>
                      {booking ? (
                        <div style={{ fontSize: 8, color: slotColor[state], fontWeight: 700, textAlign: "center", lineHeight: 1.2, padding: "0 2px" }}>
                          {booking.client.split(" ")[0]}
                        </div>
                      ) : state === "manual" ? (
                        <div style={{ fontSize: 9, color: COLORS.red }}>✗</div>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
          <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 8, textAlign: "center" }}>
            Tap any day header to see full day view · Tap a free slot to block/unblock
          </div>
        </div>
      ) : (
        /* ── DAY VIEW ── */
        <div>
          {/* Day selector */}
          <div style={{ display: "flex", gap: 6, marginBottom: 16, overflowX: "auto", paddingBottom: 4, scrollbarWidth: "none" }}>
            {DAYS.map(d => (
              <button key={d} onClick={() => setSelectedDay(d)} style={{
                flexShrink: 0, padding: "8px 12px", borderRadius: 20, border: "none", cursor: "pointer",
                background: selectedDay === d ? "#7C3AED" : COLORS.white,
                color: selectedDay === d ? "white" : COLORS.muted,
                fontWeight: 700, fontSize: 12,
                border: `1.5px solid ${selectedDay === d ? "#7C3AED" : COLORS.border}`,
              }}>
                {d} {Object.keys(AUTO_BLOCKED[d] || {}).length > 0 ? `(${Object.keys(AUTO_BLOCKED[d]).length})` : ""}
              </button>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {HOURS.map(hour => {
              const state = getSlotState(selectedDay, hour);
              const booking = AUTO_BLOCKED[selectedDay]?.[hour];
              return (
                <div key={hour} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <div style={{ width: 40, fontSize: 12, color: COLORS.muted, fontWeight: 500, textAlign: "right", flexShrink: 0 }}>{hour}</div>
                  <div onClick={() => { if (state === "free" || state === "manual") toggleManual(selectedDay, hour); }}
                    style={{
                      flex: 1, padding: "11px 14px", borderRadius: 12,
                      background: slotBg[state], border: `2px solid ${slotColor[state]}`,
                      cursor: state === "paid" || state === "pending" ? "default" : "pointer",
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                    }}>
                    {booking ? (
                      <>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 700, color: slotColor[state] }}>{booking.client}</div>
                          <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 1 }}>
                            {state === "paid" ? "🔒 Auto-locked — paid booking" : "⏳ Pending payment"}
                          </div>
                        </div>
                        <span style={{ fontSize: 11, fontWeight: 700, color: slotColor[state] }}>{slotLabel[state]}</span>
                      </>
                    ) : (
                      <>
                        <span style={{ fontSize: 13, color: slotColor[state], fontWeight: 500 }}>{slotLabel[state]}</span>
                        <span style={{ fontSize: 12, color: slotColor[state] }}>{state === "manual" ? "Tap to unblock" : "Tap to block"}</span>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Working days toggle for selected day */}
          <div style={{ marginTop: 20, padding: 14, background: COLORS.surface, borderRadius: 12, border: `1px solid ${COLORS.border}` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark }}>Working on {selectedDay}s?</div>
                <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>Toggle to mark entire day available/off</div>
              </div>
              <div onClick={() => setAvailability(prev => ({ ...prev, [selectedDay]: !prev[selectedDay] }))} style={{
                width: 44, height: 24, borderRadius: 12,
                background: availability[selectedDay] ? "#7C3AED" : COLORS.border,
                position: "relative", cursor: "pointer",
              }}>
                <div style={{ width: 18, height: 18, borderRadius: "50%", background: "white", position: "absolute", top: 3, left: availability[selectedDay] ? 23 : 3, transition: "left 0.2s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ProviderEarningsScreen() {
  const weeks = ["May W1", "May W2", "May W3", "May W4"];
  const values = [38000, 42500, 35200, 51000];
  const max = Math.max(...values);

  return (
    <div style={{ padding: "0 16px 16px" }}>
      <div style={{ paddingTop: 24, paddingBottom: 16 }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark }}>Earnings</div>
        <div style={{ fontSize: 13, color: COLORS.muted }}>May 2026</div>
      </div>

      <div style={{ background: COLORS.dark, borderRadius: 20, padding: 20, marginBottom: 20, color: "white" }}>
        <div style={{ fontSize: 12, opacity: 0.6, marginBottom: 4 }}>Available for withdrawal</div>
        <div style={{ fontSize: 36, fontWeight: 900, letterSpacing: "-1px" }}>₦38,400</div>
        <div style={{ fontSize: 12, opacity: 0.6, marginTop: 4 }}>Next settlement: Tomorrow 9AM (T+1)</div>
        <button style={{ marginTop: 14, background: "#7C3AED", color: "white", border: "none", borderRadius: 12, padding: "12px 24px", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
          Withdraw to Bank
        </button>
      </div>

      {/* Bar chart */}
      <div style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 16, padding: 16, marginBottom: 16 }}>
        <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark, marginBottom: 14 }}>Weekly Earnings</div>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-end", height: 100 }}>
          {weeks.map((w, i) => (
            <div key={w} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <div style={{ fontSize: 10, color: "#7C3AED", fontWeight: 600 }}>₦{(values[i] / 1000).toFixed(0)}k</div>
              <div style={{ width: "100%", background: i === 3 ? "#7C3AED" : "#DDD6FE", borderRadius: "4px 4px 0 0", height: `${(values[i] / max) * 80}px` }} />
              <div style={{ fontSize: 10, color: COLORS.muted }}>{w}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Breakdown */}
      <div style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 16, padding: 16 }}>
        <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark, marginBottom: 12 }}>This Month Breakdown</div>
        {[
          { label: "Gross service income", value: "₦166,700" },
          { label: "Platform booking fee (10%)", value: "−₦16,670", red: true },
          { label: "Transport fees earned (80%)", value: "+₦4,800", green: true },
          { label: "TRIM Points redeemed", value: "+₦1,200", green: true },
          { label: "Net payout", value: "₦156,030", bold: true },
        ].map(r => (
          <div key={r.label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${COLORS.border}`, fontSize: 13 }}>
            <span style={{ color: COLORS.muted }}>{r.label}</span>
            <span style={{ fontWeight: r.bold ? 800 : 600, color: r.red ? COLORS.red : r.green ? COLORS.green : COLORS.dark }}>{r.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProviderServicesScreen() {
  const [services, setServices] = useState([
    { id: 1, name: "Classic Haircut", price: 2500, duration: "45 min", active: true },
    { id: 2, name: "Fade + Beard Trim", price: 3500, duration: "60 min", active: true },
    { id: 3, name: "Shape-Up Only", price: 1500, duration: "20 min", active: true },
    { id: 4, name: "Full Styling Package", price: 4500, duration: "75 min", active: false },
  ]);
  const toggle = (id) => setServices(prev => prev.map(s => s.id === id ? { ...s, active: !s.active } : s));

  return (
    <div style={{ padding: "0 16px 16px" }}>
      <div style={{ paddingTop: 24, paddingBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark }}>My Services</div>
          <div style={{ fontSize: 13, color: COLORS.muted }}>Visible to customers on your profile</div>
        </div>
        <button style={{ background: "#7C3AED", color: "white", border: "none", borderRadius: 10, padding: "8px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
          + Add
        </button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {services.map(s => (
          <div key={s.id} style={{
            background: COLORS.white, border: `1px solid ${COLORS.border}`,
            borderRadius: 14, padding: 14,
            opacity: s.active ? 1 : 0.6,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.dark }}>{s.name}</div>
                <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>⏱ {s.duration}</div>
              </div>
              <div style={{ textAlign: "right", marginRight: 14 }}>
                <div style={{ fontWeight: 800, fontSize: 16, color: COLORS.dark }}>₦{s.price.toLocaleString()}</div>
              </div>
              <div onClick={() => toggle(s.id)} style={{
                width: 42, height: 24, borderRadius: 12,
                background: s.active ? "#7C3AED" : COLORS.border,
                position: "relative", cursor: "pointer", transition: "background 0.2s", flexShrink: 0,
              }}>
                <div style={{
                  width: 18, height: 18, borderRadius: "50%", background: "white",
                  position: "absolute", top: 3, transition: "left 0.2s",
                  left: s.active ? 21 : 3, boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                }} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 20, background: "#F5F3FF", borderRadius: 14, padding: 16 }}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#6D28D9", marginBottom: 8 }}>Mobile Barber Mode</div>
        <div style={{ fontSize: 13, color: "#7C3AED", marginBottom: 12, lineHeight: 1.5 }}>
          Enable this to appear in the mobile barber dispatch pool. You'll receive transport fee compensation (₦{BASE_RATE}/km × traffic, 80% to you).
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 13, color: "#6D28D9", fontWeight: 600 }}>Accept mobile requests</span>
          <div style={{ width: 42, height: 24, borderRadius: 12, background: "#7C3AED", position: "relative", cursor: "pointer" }}>
            <div style={{ width: 18, height: 18, borderRadius: "50%", background: "white", position: "absolute", top: 3, left: 21, boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Mini QR code rendered purely in SVG (no library needed) ──────────────────
function TinyQR({ value, size = 120 }) {
  // Simple deterministic pattern seeded from value string — decorative, not scannable
  const cells = 21;
  const cell = size / cells;
  const seed = value.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const rand = (i) => ((seed * 1103515245 + i * 12345) >>> 0) % 2;
  // Fixed finder patterns (top-left, top-right, bottom-left)
  const finder = new Set();
  for (let r = 0; r < 7; r++) for (let c = 0; c < 7; c++) finder.add(`${r},${c}`);
  for (let r = 0; r < 7; r++) for (let c = cells - 7; c < cells; c++) finder.add(`${r},${c}`);
  for (let r = cells - 7; r < cells; r++) for (let c = 0; c < 7; c++) finder.add(`${r},${c}`);

  const isFinderDark = (r, c) => {
    if (r < 7 && c < 7) return (r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4));
    if (r < 7 && c >= cells - 7) { const cc = c - (cells - 7); return (r === 0 || r === 6 || cc === 0 || cc === 6 || (r >= 2 && r <= 4 && cc >= 2 && cc <= 4)); }
    if (r >= cells - 7 && c < 7) { const rr = r - (cells - 7); return (rr === 0 || rr === 6 || c === 0 || c === 6 || (rr >= 2 && rr <= 4 && c >= 2 && c <= 4)); }
    return false;
  };

  const dots = [];
  for (let r = 0; r < cells; r++) {
    for (let c = 0; c < cells; c++) {
      const inFinder = finder.has(`${r},${c}`);
      const dark = inFinder ? isFinderDark(r, c) : rand(r * cells + c + 7) === 1;
      if (dark) dots.push(<rect key={`${r}-${c}`} x={c * cell} y={r * cell} width={cell} height={cell} fill="#1A1A1A" />);
    }
  }
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ borderRadius: 8 }}>
      <rect width={size} height={size} fill="white" />
      {dots}
    </svg>
  );
}

// ── Share Profile Modal ───────────────────────────────────────────────────────
function ShareProfileModal({ user, onClose }) {
  const handle = (user.businessName || user.name).toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
  const profileUrl = `https://trim.ng/p/${handle}`;
  const [copied, setCopied] = useState(false);
  const [shareTab, setShareTab] = useState("link"); // link | qr | whatsapp

  const copy = () => {
    navigator.clipboard?.writeText(profileUrl).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const waMessage = encodeURIComponent(
    `Hey! Book me on TRIM — Lagos's grooming platform.\n\nTap this link to see my services, pricing and available slots:\n${profileUrl}\n\n— ${user.name} (${user.businessName})`
  );

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 200,
      display: "flex", alignItems: "flex-end", justifyContent: "center",
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: COLORS.white, borderRadius: "24px 24px 0 0",
        width: "100%", maxWidth: 420, padding: "0 0 40px",
        animation: "slideUp 0.25s ease",
      }}>
        {/* Handle */}
        <div style={{ display: "flex", justifyContent: "center", paddingTop: 12, paddingBottom: 4 }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: COLORS.border }} />
        </div>

        <div style={{ padding: "12px 20px 0" }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.dark, marginBottom: 2 }}>Share Your Profile</div>
          <div style={{ fontSize: 13, color: COLORS.muted, marginBottom: 16 }}>
            Send customers directly to your booking page on TRIM
          </div>

          {/* Tab switcher */}
          <div style={{ display: "flex", background: COLORS.surface, borderRadius: 10, padding: 3, marginBottom: 20, gap: 3 }}>
            {[
              { id: "link", label: "🔗 Link" },
              { id: "qr", label: "📷 QR Code" },
              { id: "whatsapp", label: "💬 WhatsApp" },
            ].map(t => (
              <button key={t.id} onClick={() => setShareTab(t.id)} style={{
                flex: 1, padding: "8px 4px", borderRadius: 8, border: "none",
                background: shareTab === t.id ? COLORS.white : "transparent",
                color: shareTab === t.id ? COLORS.dark : COLORS.muted,
                fontSize: 12, fontWeight: 700, cursor: "pointer",
                boxShadow: shareTab === t.id ? "0 1px 4px rgba(0,0,0,0.08)" : "none",
              }}>
                {t.label}
              </button>
            ))}
          </div>

          {shareTab === "link" && (
            <>
              <div style={{ background: "#F5F3FF", borderRadius: 12, padding: "12px 14px", marginBottom: 12, display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ fontSize: 20 }}>🌐</div>
                <div style={{ flex: 1, overflow: "hidden" }}>
                  <div style={{ fontSize: 11, color: "#6D28D9", fontWeight: 600, marginBottom: 2 }}>Your booking page</div>
                  <div style={{ fontSize: 13, color: "#7C3AED", fontWeight: 700, wordBreak: "break-all" }}>{profileUrl}</div>
                </div>
              </div>
              <button onClick={copy} style={{
                width: "100%", padding: 14, borderRadius: 12, border: "none",
                background: copied ? COLORS.green : "#7C3AED",
                color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer",
                transition: "background 0.2s",
              }}>
                {copied ? "✓ Copied to clipboard!" : "Copy Link"}
              </button>
              <div style={{ marginTop: 10, fontSize: 12, color: COLORS.muted, textAlign: "center" }}>
                Anyone with this link can view your services and book an appointment
              </div>
            </>
          )}

          {shareTab === "qr" && (
            <>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, marginBottom: 16 }}>
                <div style={{ padding: 16, background: "white", borderRadius: 16, border: `1px solid ${COLORS.border}`, boxShadow: "0 4px 16px rgba(0,0,0,0.08)" }}>
                  <TinyQR value={profileUrl} size={160} />
                </div>
                <div style={{ fontSize: 12, color: COLORS.muted, textAlign: "center" }}>
                  Print this code and display it in your barbershop —<br />customers scan to book directly
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                <button style={{ padding: 12, borderRadius: 12, border: `1px solid ${COLORS.border}`, background: COLORS.white, fontSize: 13, fontWeight: 600, color: COLORS.dark, cursor: "pointer" }}>
                  💾 Save Image
                </button>
                <button style={{ padding: 12, borderRadius: 12, border: "none", background: "#7C3AED", fontSize: 13, fontWeight: 600, color: "white", cursor: "pointer" }}>
                  🖨 Print Poster
                </button>
              </div>
            </>
          )}

          {shareTab === "whatsapp" && (
            <>
              <div style={{ background: "#F0FDF4", borderRadius: 12, padding: 14, marginBottom: 16, border: "1px solid #BBF7D0" }}>
                <div style={{ fontSize: 12, color: COLORS.muted, marginBottom: 8, fontWeight: 600 }}>Preview message</div>
                <div style={{ fontSize: 13, color: COLORS.dark, lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
                  {`Hey! Book me on TRIM — Lagos's grooming platform.\n\nTap this link to see my services, pricing and available slots:\n${profileUrl}\n\n— ${user.name} (${user.businessName})`}
                </div>
              </div>
              <a href={`https://wa.me/?text=${waMessage}`} target="_blank" rel="noreferrer" style={{ textDecoration: "none" }}>
                <button style={{ width: "100%", padding: 14, borderRadius: 12, border: "none", background: "#25D366", color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
                  Share on WhatsApp
                </button>
              </a>
              <div style={{ marginTop: 10, fontSize: 12, color: COLORS.muted, textAlign: "center" }}>
                Also works for SMS, Instagram DM, or any messaging app
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Provider Shop Screen ──────────────────────────────────────────────────────
function ProviderShopScreen() {
  const CATEGORIES = ["All", "Kits", "Clippers", "Beard Care", "Accessories", "Hair Products"];
  const [cat, setCat] = useState("All");
  const [showAddModal, setShowAddModal] = useState(false);
  const [items, setItems] = useState([
    { id: 1, name: "My Signature Fade Kit", category: "Kits", price: 15000, stock: 8, emoji: "🎒", sales: 24, listed: true, desc: "Everything a client needs for the perfect home touch-up" },
    { id: 2, name: "Wahl Magic Clip (Used - Good)", category: "Clippers", price: 28000, stock: 2, emoji: "💈", sales: 3, listed: true, desc: "Lightly used, blades recently replaced" },
    { id: 3, name: "Beard Conditioning Oil (60ml)", category: "Beard Care", price: 3500, stock: 20, emoji: "🧴", sales: 41, listed: true, desc: "Natural blend of argan & jojoba. Client favourite." },
    { id: 4, name: "Barber Cape (Black)", category: "Accessories", price: 2200, stock: 0, emoji: "🦸", sales: 12, listed: false, desc: "Waterproof, heavy duty" },
    { id: 5, name: "Pomade (Medium Hold)", category: "Hair Products", price: 1800, stock: 15, emoji: "✨", sales: 67, listed: true, desc: "Nigerian-made. Water soluble." },
  ]);
  const [newItem, setNewItem] = useState({ name: "", category: "Kits", price: "", stock: "", desc: "", emoji: "📦" });

  const filtered = items.filter(i => cat === "All" || i.category === cat);
  const totalRevenue = items.reduce((a, i) => a + i.price * i.sales, 0);

  const toggleListed = (id) => setItems(prev => prev.map(i => i.id === id ? { ...i, listed: !i.listed } : i));

  const addItem = () => {
    if (!newItem.name || !newItem.price) return;
    setItems(prev => [...prev, {
      id: Date.now(), ...newItem,
      price: Number(newItem.price), stock: Number(newItem.stock) || 0,
      sales: 0, listed: true,
    }]);
    setNewItem({ name: "", category: "Kits", price: "", stock: "", desc: "", emoji: "📦" });
    setShowAddModal(false);
  };

  return (
    <div style={{ padding: "0 16px 24px" }}>
      <div style={{ paddingTop: 24, paddingBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.dark }}>My Shop</div>
          <div style={{ fontSize: 13, color: COLORS.muted }}>Sell kits & products to your customers</div>
        </div>
        <button onClick={() => setShowAddModal(true)} style={{
          background: "#7C3AED", color: "white", border: "none",
          borderRadius: 10, padding: "9px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer",
          display: "flex", alignItems: "center", gap: 5,
        }}>
          + List Item
        </button>
      </div>

      {/* Revenue summary */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
        {[
          { label: "Listed items", value: items.filter(i => i.listed).length },
          { label: "Total sold", value: items.reduce((a, i) => a + i.sales, 0) },
          { label: "Shop revenue", value: `₦${(totalRevenue / 1000).toFixed(0)}k` },
        ].map(s => (
          <div key={s.label} style={{ background: "#F5F3FF", borderRadius: 12, padding: "12px 8px", textAlign: "center", border: "1px solid #DDD6FE" }}>
            <div style={{ fontWeight: 800, fontSize: 18, color: "#6D28D9" }}>{s.value}</div>
            <div style={{ fontSize: 10, color: "#7C3AED", marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Info banner */}
      <div style={{ background: COLORS.accentLight, borderRadius: 12, padding: "10px 14px", marginBottom: 16, display: "flex", gap: 10, alignItems: "flex-start", border: `1px solid ${COLORS.accent}44` }}>
        <span style={{ fontSize: 18, flexShrink: 0 }}>💡</span>
        <div style={{ fontSize: 12, color: COLORS.accentDark, lineHeight: 1.6 }}>
          Items listed here appear on your public booking page. Customers can purchase directly when they book — or browse your shop anytime from the TRIM Marketplace.
        </div>
      </div>

      {/* Category filter */}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 8, marginBottom: 14, scrollbarWidth: "none" }}>
        {CATEGORIES.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{
            flexShrink: 0, padding: "7px 12px", borderRadius: 20,
            border: `1.5px solid ${cat === c ? "#7C3AED" : COLORS.border}`,
            background: cat === c ? "#7C3AED" : COLORS.white,
            color: cat === c ? "white" : COLORS.muted,
            fontSize: 12, fontWeight: 500, cursor: "pointer",
          }}>
            {c}
          </button>
        ))}
      </div>

      {/* Product list */}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {filtered.map(item => (
          <div key={item.id} style={{
            background: COLORS.white, border: `1px solid ${COLORS.border}`,
            borderRadius: 14, padding: 14, opacity: item.listed ? 1 : 0.55,
          }}>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div style={{ width: 52, height: 52, borderRadius: 12, background: COLORS.surface, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, flexShrink: 0 }}>
                {item.emoji}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 6 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.dark, lineHeight: 1.3 }}>{item.name}</div>
                  {/* Listed toggle */}
                  <div onClick={() => toggleListed(item.id)} style={{
                    width: 38, height: 22, borderRadius: 11, flexShrink: 0,
                    background: item.listed ? "#7C3AED" : COLORS.border,
                    position: "relative", cursor: "pointer", transition: "background 0.2s",
                  }}>
                    <div style={{
                      width: 16, height: 16, borderRadius: "50%", background: "white",
                      position: "absolute", top: 3, transition: "left 0.2s",
                      left: item.listed ? 19 : 3, boxShadow: "0 1px 2px rgba(0,0,0,0.2)",
                    }} />
                  </div>
                </div>
                <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>{item.desc}</div>
                <div style={{ display: "flex", gap: 8, marginTop: 6, alignItems: "center", flexWrap: "wrap" }}>
                  <span style={{ fontSize: 14, fontWeight: 800, color: COLORS.dark }}>₦{item.price.toLocaleString()}</span>
                  <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 10, background: item.stock === 0 ? COLORS.redBg : COLORS.surface, color: item.stock === 0 ? COLORS.red : COLORS.muted, fontWeight: 500 }}>
                    {item.stock === 0 ? "Out of stock" : `${item.stock} in stock`}
                  </span>
                  <span style={{ fontSize: 11, color: COLORS.green, fontWeight: 500 }}>
                    {item.sales} sold
                  </span>
                  <span style={{ fontSize: 10, background: item.listed ? "#F5F3FF" : COLORS.surface, color: item.listed ? "#7C3AED" : COLORS.muted, padding: "2px 7px", borderRadius: 8, fontWeight: 600, marginLeft: "auto" }}>
                    {item.listed ? "● Listed" : "Hidden"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add item modal */}
      {showAddModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 200, display: "flex", alignItems: "flex-end" }} onClick={() => setShowAddModal(false)}>
          <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 420, padding: "20px 20px 40px" }}>
            <div style={{ display: "flex", justifyContent: "center", marginBottom: 12 }}>
              <div style={{ width: 40, height: 4, borderRadius: 2, background: COLORS.border }} />
            </div>
            <div style={{ fontSize: 17, fontWeight: 800, color: COLORS.dark, marginBottom: 16 }}>List a New Item</div>

            {[
              { label: "Item Name *", key: "name", placeholder: "e.g. Beard Conditioning Oil" },
              { label: "Price (₦) *", key: "price", placeholder: "e.g. 3500", type: "number" },
              { label: "Stock quantity", key: "stock", placeholder: "e.g. 10", type: "number" },
              { label: "Short description", key: "desc", placeholder: "Tell customers what's special about this item" },
            ].map(f => (
              <div key={f.key} style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 4 }}>{f.label}</label>
                <input
                  value={newItem[f.key]} type={f.type || "text"}
                  onChange={e => setNewItem(prev => ({ ...prev, [f.key]: e.target.value }))}
                  placeholder={f.placeholder}
                  style={{ width: "100%", padding: "11px 12px", borderRadius: 10, border: `1.5px solid ${COLORS.border}`, fontSize: 13, boxSizing: "border-box" }}
                />
              </div>
            ))}

            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: COLORS.dark, display: "block", marginBottom: 6 }}>Category</label>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {["Kits", "Clippers", "Beard Care", "Accessories", "Hair Products"].map(c => (
                  <button key={c} onClick={() => setNewItem(prev => ({ ...prev, category: c }))} style={{
                    padding: "6px 12px", borderRadius: 20, fontSize: 12, cursor: "pointer",
                    border: `1.5px solid ${newItem.category === c ? "#7C3AED" : COLORS.border}`,
                    background: newItem.category === c ? "#F5F3FF" : COLORS.white,
                    color: newItem.category === c ? "#6D28D9" : COLORS.muted, fontWeight: 500,
                  }}>
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <button onClick={() => setShowAddModal(false)} style={{ padding: 13, borderRadius: 12, border: `1px solid ${COLORS.border}`, background: COLORS.white, color: COLORS.muted, fontSize: 14, cursor: "pointer" }}>
                Cancel
              </button>
              <button onClick={addItem} style={{ padding: 13, borderRadius: 12, border: "none", background: "#7C3AED", color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
                List Item →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Provider Profile Screen ───────────────────────────────────────────────────
function ProviderProfileScreen({ user, onLogout, setScreen }) {
  const [showShareModal, setShowShareModal] = useState(false);
  const handle = (user.businessName || user.name).toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
  const profileUrl = `trim.ng/p/${handle}`;

  return (
    <div style={{ padding: "0 16px 24px" }}>
      <div style={{ paddingTop: 24, paddingBottom: 16, textAlign: "center" }}>
        <div style={{ width: 72, height: 72, borderRadius: "50%", background: "#DDD6FE", border: "3px solid #7C3AED", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, fontWeight: 800, color: "#6D28D9", margin: "0 auto 10px" }}>
          {user.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
        </div>
        <div style={{ fontSize: 20, fontWeight: 800, color: COLORS.dark }}>{user.name}</div>
        <div style={{ fontSize: 14, color: "#7C3AED", fontWeight: 500 }}>{user.businessName}</div>
        <div style={{ marginTop: 6, display: "inline-flex", alignItems: "center", gap: 6, background: COLORS.greenBg, color: COLORS.green, fontSize: 12, fontWeight: 600, padding: "4px 12px", borderRadius: 20 }}>
          ✓ KYC Verified
        </div>
        {/* Public profile URL */}
        <div style={{ marginTop: 10, padding: "6px 14px", background: "#F5F3FF", borderRadius: 20, display: "inline-flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 11, color: "#7C3AED" }}>🔗</span>
          <span style={{ fontSize: 12, color: "#6D28D9", fontWeight: 600 }}>{profileUrl}</span>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 20 }}>
        {[
          { label: "Services", value: "4" },
          { label: "Avg Rating", value: "4.9★" },
          { label: "Total Paid", value: "₦312k" },
        ].map(s => (
          <div key={s.label} style={{ background: COLORS.surface, borderRadius: 10, padding: "12px 8px", textAlign: "center" }}>
            <div style={{ fontWeight: 800, fontSize: 18, color: COLORS.dark }}>{s.value}</div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── SHARE PROFILE CARD ── prominent, above the menu list */}
      <div style={{
        background: "linear-gradient(135deg, #6D28D9 0%, #4C1D95 100%)",
        borderRadius: 18, padding: 18, marginBottom: 16, color: "white",
        position: "relative", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", right: -12, top: -12, fontSize: 80, opacity: 0.08 }}>🔗</div>
        <div style={{ fontSize: 13, opacity: 0.75, marginBottom: 4, letterSpacing: "0.04em" }}>ONBOARD YOUR CUSTOMERS</div>
        <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 4 }}>Share Your Booking Page</div>
        <div style={{ fontSize: 12, opacity: 0.8, lineHeight: 1.6, marginBottom: 14 }}>
          Let your existing customers book you directly on TRIM. Share your link, QR code or WhatsApp message in seconds.
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => setShowShareModal(true)} style={{
            flex: 1, background: "white", color: "#6D28D9", border: "none",
            borderRadius: 12, padding: "12px 0", fontSize: 13, fontWeight: 800, cursor: "pointer",
          }}>
            🔗 Share Profile
          </button>
          <button onClick={() => setShowShareModal(true)} style={{
            background: "rgba(255,255,255,0.15)", color: "white", border: "1px solid rgba(255,255,255,0.3)",
            borderRadius: 12, padding: "12px 14px", fontSize: 13, fontWeight: 600, cursor: "pointer",
          }}>
            📷 QR
          </button>
        </div>
      </div>

      {/* ── MY SHOP CARD ── */}
      <div onClick={() => setScreen("providerShop")} style={{
        background: COLORS.white, border: `1.5px solid ${COLORS.accent}88`,
        borderRadius: 18, padding: 18, marginBottom: 16, cursor: "pointer",
        display: "flex", alignItems: "center", gap: 14,
      }}>
        <div style={{ width: 52, height: 52, borderRadius: 14, background: COLORS.accentLight, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, flexShrink: 0 }}>
          🛍
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: 15, color: COLORS.dark }}>My Shop</div>
          <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>Sell kits, tools & products to your customers</div>
          <div style={{ fontSize: 12, color: COLORS.accent, fontWeight: 600, marginTop: 4 }}>5 items listed · ₦783k in sales →</div>
        </div>
      </div>

      {/* Settings menu */}
      <div style={{ background: COLORS.white, border: `1px solid ${COLORS.border}`, borderRadius: 16, overflow: "hidden", marginBottom: 20 }}>
        {[
          { icon: "🪪", label: "KYC & Verification", sub: "BVN · NIN · Liveness ✓" },
          { icon: "🏦", label: "Bank Account", sub: "GTBank ···4821" },
          { icon: "📣", label: "Refer a Barber", sub: "Earn ₦2,000 per referral", highlight: true },
          { icon: "🎓", label: "TRIM Academy", sub: "2 courses in progress" },
          { icon: "📍", label: "Service Zones", sub: "Ikeja · Lekki · VI" },
          { icon: "⚙️", label: "Settings & Notifications", sub: "" },
        ].map((item, i) => (
          <div key={item.label} style={{
            display: "flex", alignItems: "center", gap: 12, padding: "14px 16px",
            borderTop: i > 0 ? `1px solid ${COLORS.border}` : "none",
            cursor: "pointer", background: item.highlight ? "#F5F3FF" : COLORS.white,
          }}>
            <span style={{ fontSize: 20 }}>{item.icon}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: item.highlight ? "#6D28D9" : COLORS.dark }}>{item.label}</div>
              {item.sub && <div style={{ fontSize: 12, color: COLORS.muted }}>{item.sub}</div>}
            </div>
            <span style={{ color: COLORS.muted, fontSize: 16 }}>›</span>
          </div>
        ))}
      </div>

      <button onClick={onLogout} style={{
        width: "100%", padding: 14, borderRadius: 14,
        border: `1px solid ${COLORS.border}`, background: COLORS.white,
        color: COLORS.red, fontSize: 14, fontWeight: 600, cursor: "pointer",
      }}>
        Log Out
      </button>

      {/* Share modal */}
      {showShareModal && <ShareProfileModal user={user} onClose={() => setShowShareModal(false)} />}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function TRIMApp() {
  // auth state: null = splash, {role, name, …} = logged in
  const [authUser, setAuthUser] = useState(null);
  const [authStep, setAuthStep] = useState("splash"); // splash | auth
  const [authRole, setAuthRole] = useState(null);

  // customer nav
  const [screen, setScreen] = useState("home");
  const [selectedBarber, setSelectedBarber] = useState(null);
  const [bookingBarber, setBookingBarber] = useState(null);
  const [cart, setCart] = useState([]);

  // provider nav
  const [providerScreen, setProviderScreen] = useState("providerHome");

  const handleSelectRole = (role) => {
    setAuthRole(role);
    setAuthStep("auth");
  };

  const handleAuth = (user) => {
    setAuthUser(user);
    if (user.role === "provider") setProviderScreen("providerHome");
    else setScreen("home");
  };

  const handleLogout = () => {
    setAuthUser(null);
    setAuthStep("splash");
    setAuthRole(null);
    setScreen("home");
    setProviderScreen("providerHome");
  };

  // ── Not logged in ──
  if (!authUser) {
    if (authStep === "splash") return <SplashScreen onRole={handleSelectRole} />;
    return <AuthScreen role={authRole} onAuth={handleAuth} onBack={() => setAuthStep("splash")} />;
  }

  // ── Provider experience ──
  if (authUser.role === "provider") {
    const providerShowNav = true;
    const renderProvider = () => {
      switch (providerScreen) {
        case "providerHome":     return <ProviderHomeScreen user={authUser} setScreen={setProviderScreen} />;
        case "providerCalendar": return <ProviderCalendarScreen />;
        case "providerEarnings": return <ProviderEarningsScreen />;
        case "providerServices": return <ProviderServicesScreen />;
        case "providerShop":     return <ProviderShopScreen />;
        case "providerProfile":  return <ProviderProfileScreen user={authUser} onLogout={handleLogout} setScreen={setProviderScreen} />;
        default: return <ProviderHomeScreen user={authUser} setScreen={setProviderScreen} />;
      }
    };
    return (
      <div style={{
        maxWidth: 420, margin: "0 auto", minHeight: "100vh",
        background: COLORS.surface,
        fontFamily: "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
        display: "flex", flexDirection: "column",
      }}>
        <div style={{
          background: COLORS.dark, padding: "10px 16px 8px",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          position: "sticky", top: 0, zIndex: 50,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 18 }}>✂</span>
            <span style={{ fontSize: 18, fontWeight: 900, color: "white", letterSpacing: "-0.5px" }}>TRIM</span>
            <span style={{ fontSize: 11, background: "#7C3AED", color: "white", padding: "2px 8px", borderRadius: 6, fontWeight: 600 }}>Provider</span>
          </div>
          <div style={{ fontSize: 11, color: COLORS.greenBg, fontWeight: 600 }}>● Online</div>
        </div>
        <div style={{ flex: 1, overflowY: "auto" }}>{renderProvider()}</div>
        <ProviderBottomNav screen={providerScreen} setScreen={setProviderScreen} />
      </div>
    );
  }

  // ── Customer experience ──
  const showNav = !["booking", "mobile", "transportCalc", "cart"].includes(screen);

  const renderCustomer = () => {
    switch (screen) {
      case "home":          return <HomeScreen setScreen={setScreen} setSelectedBarber={setSelectedBarber} />;
      case "discover":      return <DiscoverScreen setScreen={setScreen} setSelectedBarber={setSelectedBarber} />;
      case "barberProfile": return <BarberProfileScreen barber={selectedBarber} setScreen={setScreen} setBookingBarber={setBookingBarber} />;
      case "booking":       return <BookingScreen barber={bookingBarber || selectedBarber} setScreen={setScreen} />;
      case "mobile":        return <MobileBarberScreen setScreen={setScreen} />;
      case "transportCalc": return <TransportCalcScreen setScreen={setScreen} />;
      case "bookings":      return <BookingsScreen />;
      case "marketplace":   return <MarketplaceScreen setScreen={setScreen} cart={cart} setCart={setCart} />;
      case "cart":          return <CartScreen setScreen={setScreen} cart={cart} setCart={setCart} />;
      case "profile":       return <ProfileScreen setScreen={setScreen} user={authUser} onLogout={handleLogout} />;
      default:              return <HomeScreen setScreen={setScreen} setSelectedBarber={setSelectedBarber} />;
    }
  };

  return (
    <div style={{
      maxWidth: 420, margin: "0 auto", minHeight: "100vh",
      background: COLORS.surface,
      fontFamily: "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
      display: "flex", flexDirection: "column",
    }}>
      <div style={{
        background: COLORS.surface, padding: "10px 16px 8px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        borderBottom: `1px solid ${COLORS.border}`,
        position: "sticky", top: 0, zIndex: 50,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 20 }}>✂</span>
          <span style={{ fontSize: 18, fontWeight: 900, letterSpacing: "-0.5px", color: COLORS.dark }}>TRIM</span>
          <span style={{ fontSize: 11, background: COLORS.accentLight, color: COLORS.accentDark, padding: "2px 6px", borderRadius: 6, fontWeight: 600 }}>Lagos</span>
        </div>
        <span style={{ color: COLORS.green, fontWeight: 600, fontSize: 11 }}>● Online</span>
      </div>
      <div style={{ flex: 1, overflowY: "auto" }}>{renderCustomer()}</div>
      {showNav && <BottomNav screen={screen} setScreen={setScreen} />}
    </div>
  );
}
